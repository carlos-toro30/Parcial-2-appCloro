# Planificación (Trello) y convenciones de Git

> Esta guía ordena el trabajo en pareja para la Evaluación Parcial 2. El tablero y el repositorio los crea y alimenta el equipo: la rúbrica (IE 2.3.2) evalúa commits e issues **reales** y distribuidos entre ambos integrantes.

## Tablero Trello sugerido
Columnas: **Backlog · En progreso · En revisión · Hecho**. Una tarjeta por funcionalidad, con responsable y fecha.

| Tarjeta | Pauta que cubre |
| :--- | :--- |
| Diseño de pantallas y navegación (Login, Puntos, Alertas, Registrar, Panel, Perfil) | IE 2.1.1 |
| Formularios con validación e íconos (Login, Crear cuenta, Medición, Acción, Corrección, Rangos) | IE 2.1.2 |
| Validaciones en `Validaciones.kt` y ViewModels | IE 2.2.1 |
| Animaciones (gráfico, barras, pulso crítico, indicador de contraseña) | IE 2.2.2 |
| Estructura MVVM y persistencia local (`AlmacenLocal`) | IE 2.3.1 |
| README, tests unitarios, tablero Trello | IE 2.3.2 |
| Recursos nativos: notificaciones, estado de red, compartir/exportar CSV | IE 2.4.1 |

## Convenciones de commits
Mensajes técnicos, en infinitivo o pasado, que expliquen el cambio. Ejemplos:

- `feat(login): agregar validación de correo y contraseña en LoginViewModel`
- `feat(registro): crear formulario de cuenta con persistencia local de usuarios`
- `feat(alertas): generar alerta automática y escalar advertencia a crítica`
- `feat(reportes): exportar mediciones, desviaciones y acciones a CSV`
- `refactor(validaciones): extraer reglas de formularios a utils/Validaciones`
- `test(validaciones): cubrir límites de ppm, correo y contraseña`
- `docs(readme): documentar pasos de ejecución y reglas de negocio`

Evitar mensajes como "cambios", "arreglos" o "update". Cada integrante debe commitear su parte (ramas `feature/...` + Pull Request al integrar).

## Antes de la entrega
- Repositorio **público**, con acceso al docente y a ambos integrantes.
- **No hacer commits después de la fecha de entrega** (la rúbrica lo penaliza con nota 1.0).
- Subir el mismo código al enlace de AVA grupal (un solo integrante) y activar el AVA individual.
