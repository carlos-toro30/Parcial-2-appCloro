package com.duoc.monitorcloro

import com.duoc.monitorcloro.model.EstadoCloro
import com.duoc.monitorcloro.model.RangosCloro
import com.duoc.monitorcloro.model.TipoDesviacion
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RangosCloroTest {
    private val r = RangosCloro() // 2 / 3 / 5 / 6 ppm

    @Test
    fun normal_entre_3_y_5_inclusive() {
        assertEquals(EstadoCloro.NORMAL, r.evaluar(3.0))
        assertEquals(EstadoCloro.NORMAL, r.evaluar(4.2))
        assertEquals(EstadoCloro.NORMAL, r.evaluar(5.0))
    }

    @Test
    fun advertencia_bajo_y_alto() {
        assertEquals(EstadoCloro.ADVERTENCIA, r.evaluar(2.0))
        assertEquals(EstadoCloro.ADVERTENCIA, r.evaluar(2.99))
        assertEquals(EstadoCloro.ADVERTENCIA, r.evaluar(5.01))
        assertEquals(EstadoCloro.ADVERTENCIA, r.evaluar(6.0))
    }

    @Test
    fun critico_bajo_2_o_sobre_6() {
        assertEquals(EstadoCloro.CRITICO, r.evaluar(1.99))
        assertEquals(EstadoCloro.CRITICO, r.evaluar(6.01))
    }

    @Test
    fun tipo_de_desviacion() {
        assertEquals(TipoDesviacion.BAJO, r.desviacion(2.5))
        assertEquals(TipoDesviacion.ALTO, r.desviacion(5.5))
        assertNull(r.desviacion(4.0))
    }

    @Test
    fun validacion_de_rangos_configurables() {
        assertTrue(r.esValido())
        assertFalse(RangosCloro(3.0, 2.0, 5.0, 6.0).esValido())
        assertFalse(RangosCloro(2.0, 3.0, 6.0, 5.0).esValido())
    }
}
