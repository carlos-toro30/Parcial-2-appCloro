package com.duoc.monitorcloro

import com.duoc.monitorcloro.utils.Validaciones
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ValidacionesTest {

    @Test
    fun ppm_acepta_coma_y_punto() {
        assertNull(Validaciones.ppm("3,50"))
        assertNull(Validaciones.ppm("3.5"))
        assertEquals(3.5, Validaciones.parsearPpm("3,50")!!, 0.0001)
    }

    @Test
    fun ppm_rechaza_vacio_texto_y_fuera_de_rango() {
        assertNotNull(Validaciones.ppm(""))
        assertNotNull(Validaciones.ppm("abc"))
        assertNotNull(Validaciones.ppm("-1"))
        assertNotNull(Validaciones.ppm("10,01"))
        assertNull(Validaciones.ppm("0"))
        assertNull(Validaciones.ppm("10"))
    }

    @Test
    fun limite_de_rango_debe_ser_positivo() {
        assertNotNull(Validaciones.limiteRango(""))
        assertNotNull(Validaciones.limiteRango("0"))
        assertNull(Validaciones.limiteRango("2,5"))
    }

    @Test
    fun correo_valido_e_invalido() {
        assertNull(Validaciones.email("ana@cloro-demo.cl"))
        assertNotNull(Validaciones.email(""))
        assertNotNull(Validaciones.email("sin-arroba"))
        assertNotNull(Validaciones.email("a@b"))
    }

    @Test
    fun nombre_y_textos_minimos() {
        assertNull(Validaciones.nombre("María Núñez"))
        assertNotNull(Validaciones.nombre("Al"))
        assertNotNull(Validaciones.nombre("Juan123"))
        assertNotNull(Validaciones.descripcionAccion("corta"))
        assertNull(Validaciones.descripcionAccion("Se purgó la línea"))
        assertNotNull(Validaciones.motivoCorreccion("ab"))
        assertNull(Validaciones.motivoCorreccion("Error de lectura"))
    }

    @Test
    fun contrasena_nueva_y_confirmacion() {
        assertNotNull(Validaciones.passwordNueva("12345"))
        assertNull(Validaciones.passwordNueva("123456"))
        assertNull(Validaciones.confirmacion("abc123", "abc123"))
        assertNotNull(Validaciones.confirmacion("abc123", "abc124"))
    }

    @Test
    fun fuerza_de_contrasena_crece() {
        assertTrue(Validaciones.fuerzaPassword("abc") < Validaciones.fuerzaPassword("Abcdef123x"))
        assertEquals(1f, Validaciones.fuerzaPassword("Abcdefgh12"), 0.001f)
    }
}
