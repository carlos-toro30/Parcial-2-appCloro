package com.duoc.monitorcloro

import com.duoc.monitorcloro.data.DatosSimulados
import com.duoc.monitorcloro.model.resumenDe
import com.duoc.monitorcloro.utils.Formato
import com.duoc.monitorcloro.utils.Reportes
import com.duoc.monitorcloro.utils.Seguridad
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class UtilidadesTest {

    @Test
    fun valores_con_dos_decimales_y_coma() {
        assertEquals("3,50", Formato.valor(3.5))
        assertEquals("3,50 ppm", Formato.ppm(3.5))
        assertEquals("0,05", Formato.valor(0.05))
    }

    @Test
    fun duracion_legible() {
        assertEquals("menos de 1 min", Formato.duracion(0))
        assertEquals("15 min", Formato.duracion(15 * 60_000L))
        assertEquals("2 h 10 min", Formato.duracion(130 * 60_000L))
        assertEquals("1 d 3 h", Formato.duracion(27 * 3_600_000L))
    }

    @Test
    fun resumen_promedio_maximo_minimo() {
        val r = resumenDe(listOf(2.0, 4.0, 6.0))!!
        assertEquals(4.0, r.promedio, 0.001)
        assertEquals(6.0, r.maximo, 0.001)
        assertEquals(2.0, r.minimo, 0.001)
        assertEquals(3, r.cantidad)
        assertNull(resumenDe(emptyList()))
    }

    @Test
    fun contrasenas_se_guardan_como_hash() {
        val hash = Seguridad.hash("cloro123")
        assertEquals(64, hash.length)
        assertNotEquals("cloro123", hash)
        assertEquals(hash, Seguridad.hash("cloro123"))
        assertNotEquals(hash, Seguridad.hash("otra"))
    }

    @Test
    fun autenticacion_con_hash() {
        assertNotNull(DatosSimulados.autenticar("juan.perez@cloro-demo.cl", "cloro123"))
        assertNotNull(DatosSimulados.autenticar(" ANA.MORALES@cloro-demo.cl ", "cloro123"))
        assertNull(DatosSimulados.autenticar("juan.perez@cloro-demo.cl", "mala"))
        assertNull(DatosSimulados.autenticar("nadie@cloro-demo.cl", "cloro123"))
    }

    @Test
    fun datos_simulados_cumplen_el_caso() {
        assertEquals(3, DatosSimulados.granjas.size)
        assertEquals(12, DatosSimulados.granjas.sumOf { it.puntos.size })
        assertEquals(15, DatosSimulados.usuarios.size)
    }

    @Test
    fun celda_csv_escapa_comillas_y_saltos_de_linea() {
        assertEquals("\"hola\"", Reportes.celda("hola"))
        assertEquals("\"dijo \"\"ok\"\"\"", Reportes.celda("dijo \"ok\""))
        assertEquals("\"a b\"", Reportes.celda("a\nb"))
    }
}
