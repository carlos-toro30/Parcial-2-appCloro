package com.duoc.monitorcloro.utils

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

/** Indica si el dispositivo tiene una red activa con salida a internet. */
fun hayConexionInternet(context: Context): Boolean {
    return try {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val red = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(red) ?: return false
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (e: SecurityException) {
        false
    }
}
