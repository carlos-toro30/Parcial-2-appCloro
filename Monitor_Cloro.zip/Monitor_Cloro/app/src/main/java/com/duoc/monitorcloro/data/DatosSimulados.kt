package com.duoc.monitorcloro.data

import com.duoc.monitorcloro.model.Granja
import com.duoc.monitorcloro.model.PuntoMedicion
import com.duoc.monitorcloro.model.Rol
import com.duoc.monitorcloro.model.TipoPunto
import com.duoc.monitorcloro.model.Usuario
import com.duoc.monitorcloro.utils.Seguridad

/** Datos maestros 100% ficticios: 3 granjas x 4 puntos y 15 usuarios. */
object DatosSimulados {

    const val PASSWORD_DEMO = "cloro123"

    /** Las contraseñas se almacenan como hash SHA-256, no en texto plano. */
    private val HASH_DEMO = Seguridad.hash(PASSWORD_DEMO)

    val usuarios: List<Usuario> = listOf(
        // Operarios
        Usuario(1, "Juan Pérez", "juan.perez@cloro-demo.cl", HASH_DEMO, Rol.OPERARIO, listOf(1)),
        Usuario(2, "María González", "maria.gonzalez@cloro-demo.cl", HASH_DEMO, Rol.OPERARIO, listOf(1, 2)),
        Usuario(3, "Pedro Rojas", "pedro.rojas@cloro-demo.cl", HASH_DEMO, Rol.OPERARIO, listOf(2)),
        Usuario(4, "Luisa Contreras", "luisa.contreras@cloro-demo.cl", HASH_DEMO, Rol.OPERARIO, listOf(2)),
        Usuario(5, "Diego Fuentes", "diego.fuentes@cloro-demo.cl", HASH_DEMO, Rol.OPERARIO, listOf(3)),
        Usuario(6, "Camila Soto", "camila.soto@cloro-demo.cl", HASH_DEMO, Rol.OPERARIO, listOf(3)),
        Usuario(7, "Andrés Vega", "andres.vega@cloro-demo.cl", HASH_DEMO, Rol.OPERARIO, listOf(1)),
        Usuario(8, "Paula Núñez", "paula.nunez@cloro-demo.cl", HASH_DEMO, Rol.OPERARIO, listOf(3)),
        // Supervisores
        Usuario(9, "Carlos Silva", "carlos.silva@cloro-demo.cl", HASH_DEMO, Rol.SUPERVISOR, listOf(1)),
        Usuario(10, "Roberto Díaz", "roberto.diaz@cloro-demo.cl", HASH_DEMO, Rol.SUPERVISOR, listOf(2)),
        Usuario(11, "Fernanda Reyes", "fernanda.reyes@cloro-demo.cl", HASH_DEMO, Rol.SUPERVISOR, listOf(3)),
        Usuario(12, "Marcela Ortiz", "marcela.ortiz@cloro-demo.cl", HASH_DEMO, Rol.SUPERVISOR, listOf(2, 3)),
        // Jefaturas
        Usuario(13, "Ana Morales", "ana.morales@cloro-demo.cl", HASH_DEMO, Rol.JEFATURA, listOf(1, 2, 3)),
        Usuario(14, "Héctor Paredes", "hector.paredes@cloro-demo.cl", HASH_DEMO, Rol.JEFATURA, listOf(1, 2, 3)),
        Usuario(15, "Valentina Cruz", "valentina.cruz@cloro-demo.cl", HASH_DEMO, Rol.JEFATURA, listOf(1, 2, 3))
    )

    private fun puntosDe(granjaId: Int, prefijo: String): List<PuntoMedicion> {
        val base = (granjaId - 1) * 4
        return listOf(
            PuntoMedicion(base + 1, granjaId, "Galpón 1", "$prefijo-G1-TQ", "Sala de bombeo", TipoPunto.TANQUE),
            PuntoMedicion(base + 2, granjaId, "Galpón 1", "$prefijo-G1-LD", "Pasillo central", TipoPunto.LINEA),
            PuntoMedicion(base + 3, granjaId, "Galpón 2", "$prefijo-G2-BD", "Extremo línea norte", TipoPunto.BEBEDERO),
            PuntoMedicion(base + 4, granjaId, "Galpón 3", "$prefijo-G3-BD", "Extremo línea sur", TipoPunto.BEBEDERO)
        )
    }

    val granjas: List<Granja> = listOf(
        Granja(1, "Granja Melipilla", "Melipilla, RM", puntosDe(1, "MEL")),
        Granja(2, "Granja San Antonio", "San Antonio, V Región", puntosDe(2, "SAN")),
        Granja(3, "Granja Talca", "Talca, VII Región", puntosDe(3, "TAL"))
    )

    /** Usuarios creados desde el formulario "Crear cuenta" (se cargan desde el almacenamiento local). */
    @Volatile
    var usuariosRegistrados: List<Usuario> = emptyList()

    val todosLosUsuarios: List<Usuario> get() = usuarios + usuariosRegistrados

    fun autenticar(email: String, password: String): Usuario? =
        todosLosUsuarios.firstOrNull { it.email.equals(email.trim(), ignoreCase = true) && it.passwordHash == Seguridad.hash(password) }

    fun usuarioPorId(id: Int): Usuario? = todosLosUsuarios.firstOrNull { it.id == id }
}
