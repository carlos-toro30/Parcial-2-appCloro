package com.duoc.monitorcloro.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Opacity
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.duoc.monitorcloro.model.RangosCloro
import com.duoc.monitorcloro.utils.Formato
import com.duoc.monitorcloro.utils.Validaciones

/** Diálogo para ingresar una medición de cloro libre (por ejemplo, verificación tras una acción). */
@Composable
fun DialogoMedicion(
    titulo: String,
    rangos: RangosCloro,
    onConfirmar: (Double) -> Unit,
    onCerrar: () -> Unit
) {
    var texto by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val valor = Validaciones.parsearPpm(texto)

    AlertDialog(
        onDismissRequest = onCerrar,
        title = { Text(titulo) },
        text = {
            Column {
                CampoTexto(
                    valor = texto,
                    alCambiar = { texto = it; error = null },
                    etiqueta = "Cloro libre (ppm)",
                    icono = Icons.Default.Opacity,
                    error = error,
                    teclado = KeyboardType.Decimal
                )
                if (valor != null && Validaciones.ppm(texto) == null) {
                    Spacer(Modifier.height(8.dp))
                    val estado = rangos.evaluar(valor)
                    Text("Estado con este valor: ${estado.etiqueta}", color = estado.color(),
                        style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                error = Validaciones.ppm(texto)
                if (error == null) Validaciones.parsearPpm(texto)?.let(onConfirmar)
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onCerrar) { Text("Cancelar") } }
    )
}

/** Diálogo para corregir una medición: exige nuevo valor y motivo. El original se conserva. */
@Composable
fun DialogoCorreccion(
    valorOriginal: Double,
    onConfirmar: (Double, String) -> Unit,
    onCerrar: () -> Unit
) {
    var texto by remember { mutableStateOf("") }
    var motivo by remember { mutableStateOf("") }
    var errorValor by remember { mutableStateOf<String?>(null) }
    var errorMotivo by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onCerrar,
        title = { Text("Corregir medición") },
        text = {
            Column {
                Text(
                    "Valor original: ${Formato.ppm(valorOriginal)}. El original se conserva en el historial " +
                        "y la corrección queda registrada con tu usuario, fecha y motivo.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(8.dp))
                CampoTexto(
                    valor = texto,
                    alCambiar = { texto = it; errorValor = null },
                    etiqueta = "Valor corregido (ppm)",
                    icono = Icons.Default.Opacity,
                    error = errorValor,
                    teclado = KeyboardType.Decimal
                )
                CampoTexto(
                    valor = motivo,
                    alCambiar = { motivo = it; errorMotivo = null },
                    etiqueta = "Motivo de la corrección",
                    icono = Icons.Default.Edit,
                    error = errorMotivo
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                errorValor = Validaciones.ppm(texto)
                errorMotivo = Validaciones.motivoCorreccion(motivo)
                val v = Validaciones.parsearPpm(texto)
                if (errorValor == null && errorMotivo == null && v != null) onConfirmar(v, motivo)
            }) { Text("Guardar corrección") }
        },
        dismissButton = { TextButton(onClick = onCerrar) { Text("Cancelar") } }
    )
}
