package com.duoc.monitorcloro.utils

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Formato {
    private val locale: Locale = Locale.forLanguageTag("es-CL")

    /** Dos decimales con coma: 3,50 */
    fun valor(v: Double): String = String.format(locale, "%.2f", v)

    fun ppm(v: Double): String = "${valor(v)} ppm"

    fun fechaHora(ms: Long): String = SimpleDateFormat("dd-MM-yyyy HH:mm", locale).format(Date(ms))

    fun hora(ms: Long): String = SimpleDateFormat("HH:mm", locale).format(Date(ms))

    fun diaHora(ms: Long): String = SimpleDateFormat("dd/MM HH:mm", locale).format(Date(ms))

    /** Duración legible: "15 min", "2 h 10 min", "1 d 3 h". */
    fun duracion(ms: Long): String {
        val min = (ms / 60_000L).coerceAtLeast(0)
        return when {
            min < 1 -> "menos de 1 min"
            min < 60 -> "$min min"
            min < 1440 -> "${min / 60} h ${min % 60} min"
            else -> "${min / 1440} d ${(min % 1440) / 60} h"
        }
    }

    fun hace(ms: Long, ahora: Long = System.currentTimeMillis()): String {
        val min = (ahora - ms) / 60_000L
        return if (min < 1) "hace instantes" else "hace ${duracion(ahora - ms)}"
    }
}
