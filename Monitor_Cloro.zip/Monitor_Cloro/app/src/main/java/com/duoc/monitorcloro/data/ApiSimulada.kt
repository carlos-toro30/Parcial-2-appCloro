package com.duoc.monitorcloro.data

import com.google.gson.Gson
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import okio.Buffer
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/**
 * Genera mediciones ficticias y deterministas: el valor depende solo del punto y del instante,
 * por lo que la serie histórica y las lecturas actuales son coherentes entre sí.
 */
object GeneradorMediciones {
    /** Frecuencia de las lecturas automáticas simuladas (el caso propone 5 minutos). */
    const val INTERVALO_MS = 5 * 60_000L
    private const val HORA_MS = 3_600_000L
    private const val DIA_MS = 24 * HORA_MS

    // punto -> (valor base ppm, amplitud). Algunos puntos oscilan hasta salir de rango a propósito.
    private val perfiles: Map<Int, Pair<Double, Double>> = mapOf(
        1 to (4.0 to 0.4), 2 to (3.6 to 0.9), 3 to (2.6 to 1.0), 4 to (4.2 to 0.5),
        5 to (4.4 to 1.0), 6 to (3.9 to 0.3), 7 to (5.2 to 1.1), 8 to (4.0 to 0.4),
        9 to (3.1 to 0.8), 10 to (4.5 to 0.6), 11 to (4.0 to 0.3), 12 to (2.8 to 1.4)
    )

    fun valor(puntoId: Int, tMillis: Long): Double {
        val (base, amplitud) = perfiles[puntoId] ?: (4.0 to 0.4)
        val periodo = (6 + puntoId) * HORA_MS.toDouble()
        val onda = sin(2 * PI * (tMillis / periodo) + puntoId * 0.9)
        val ruido = Random(puntoId * 7919L + tMillis / 60_000L).nextDouble(-0.12, 0.12)
        val v = (base + amplitud * onda + ruido).coerceAtLeast(0.2)
        return (v * 100).roundToInt() / 100.0
    }

    fun lecturaActual(puntoId: Int, ahora: Long): MedicionDto {
        val t = ahora - ahora % INTERVALO_MS
        return MedicionDto("P$puntoId-$t", puntoId, valor(puntoId, t), t, "AUTOMATICA", null)
    }

    fun serie(puntoId: Int, dias: Int, ahora: Long): List<MedicionDto> {
        val paso = when (dias) {
            1 -> 15 * 60_000L
            7 -> HORA_MS
            else -> 6 * HORA_MS
        }
        val inicio = (ahora - dias * DIA_MS).let { it - it % paso } + paso
        val fin = ahora - ahora % paso
        val lista = mutableListOf<MedicionDto>()
        var t = inicio
        while (t <= fin) {
            lista.add(MedicionDto("P$puntoId-$t", puntoId, valor(puntoId, t), t, "AUTOMATICA", null))
            t += paso
        }
        return lista
    }
}

/**
 * "Servidor" REST simulado: intercepta las llamadas de Retrofit y responde JSON como lo haría
 * un backend real. Así la app usa Retrofit/OkHttp/Gson de verdad, sin necesitar infraestructura.
 */
class ApiSimuladaInterceptor : Interceptor {
    private val gson = Gson()

    companion object {
        /** Lecturas forzadas para demostración (punto -> ppm). Se consumen en la siguiente consulta. */
        private val forzadas = ConcurrentHashMap<Int, Double>()

        fun forzarLectura(puntoId: Int, valor: Double) {
            forzadas[puntoId] = valor
        }
    }

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val ruta = request.url.encodedPath
        val ahora = System.currentTimeMillis()
        Thread.sleep(300) // latencia de red simulada

        return when {
            request.method == "GET" && ruta == "/api/v1/granjas" -> {
                val dto = DatosSimulados.granjas.map { g ->
                    GranjaDto(
                        g.id, g.nombre, g.ubicacion,
                        g.puntos.map { PuntoDto(it.id, it.granjaId, it.galpon, it.codigo, it.ubicacion, it.tipo.name) }
                    )
                }
                responder(chain, 200, gson.toJson(dto))
            }

            request.method == "GET" && ruta == "/api/v1/mediciones/actuales" -> {
                val lista = DatosSimulados.granjas.flatMap { it.puntos }.map { p ->
                    val forzado = forzadas.remove(p.id)
                    if (forzado != null) {
                        MedicionDto("P${p.id}-F$ahora", p.id, forzado, ahora, "AUTOMATICA", null)
                    } else {
                        GeneradorMediciones.lecturaActual(p.id, ahora)
                    }
                }
                responder(chain, 200, gson.toJson(lista))
            }

            request.method == "GET" && ruta == "/api/v1/mediciones" -> {
                val dias = request.url.queryParameter("dias")?.toIntOrNull() ?: 1
                val lista = DatosSimulados.granjas.flatMap { it.puntos }
                    .flatMap { GeneradorMediciones.serie(it.id, dias, ahora) }
                responder(chain, 200, gson.toJson(lista))
            }

            request.method == "POST" && ruta == "/api/v1/mediciones" -> {
                val buffer = Buffer()
                request.body?.writeTo(buffer)
                responder(chain, 201, buffer.readUtf8())
            }

            else -> responder(chain, 404, "{\"error\":\"Recurso no encontrado\"}")
        }
    }

    private fun responder(chain: Interceptor.Chain, codigo: Int, cuerpo: String): Response =
        Response.Builder()
            .request(chain.request())
            .protocol(Protocol.HTTP_1_1)
            .code(codigo)
            .message(if (codigo in 200..299) "OK" else "Error")
            .body(cuerpo.toResponseBody("application/json; charset=utf-8".toMediaType()))
            .build()
}
