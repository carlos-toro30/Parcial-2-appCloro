package com.duoc.monitorcloro.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.duoc.monitorcloro.data.DatosSimulados
import com.duoc.monitorcloro.model.Usuario
import com.duoc.monitorcloro.utils.Validaciones

/** Estado y validación del formulario de inicio de sesión (correo ficticio + contraseña). */
class LoginViewModel : ViewModel() {
    var emailInput by mutableStateOf("")
    var passwordInput by mutableStateOf("")
    var mostrarPassword by mutableStateOf(false)

    var errorEmail by mutableStateOf<String?>(null); private set
    var errorPassword by mutableStateOf<String?>(null); private set
    var errorGeneral by mutableStateOf<String?>(null); private set

    fun autenticar(): Usuario? {
        errorEmail = null
        errorPassword = null
        errorGeneral = null

        val email = emailInput.trim()
        errorEmail = Validaciones.email(email)
        errorPassword = Validaciones.passwordLogin(passwordInput)
        if (errorEmail != null || errorPassword != null) return null

        val usuario = DatosSimulados.autenticar(email, passwordInput)
        if (usuario == null) errorGeneral = "Correo o contraseña incorrectos."
        return usuario
    }

    fun usarCredencialesDemo(email: String) {
        emailInput = email
        passwordInput = DatosSimulados.PASSWORD_DEMO
        errorEmail = null; errorPassword = null; errorGeneral = null
    }
}
