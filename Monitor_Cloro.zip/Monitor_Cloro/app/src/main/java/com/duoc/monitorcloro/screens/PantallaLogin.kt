package com.duoc.monitorcloro.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.duoc.monitorcloro.components.CampoTexto
import com.duoc.monitorcloro.components.EstadoConexionBadge
import com.duoc.monitorcloro.data.DatosSimulados
import com.duoc.monitorcloro.model.Usuario
import com.duoc.monitorcloro.viewmodel.LoginViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaLogin(
    online: Boolean,
    loginViewModel: LoginViewModel = viewModel(),
    onLoginExitoso: (Usuario) -> Unit,
    onCrearCuenta: () -> Unit = {}
) {
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Monitor de Cloro") },
                actions = { Box(Modifier.padding(end = 12.dp)) { EstadoConexionBadge(online) } }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .padding(24.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Control de cloro libre en línea", style = MaterialTheme.typography.titleMedium)
            Text(
                "Inicia sesión con tu correo",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(20.dp))

            CampoTexto(
                valor = loginViewModel.emailInput,
                alCambiar = { loginViewModel.emailInput = it },
                etiqueta = "Correo electrónico",
                icono = Icons.Default.Email,
                error = loginViewModel.errorEmail,
                teclado = KeyboardType.Email
            )

            Spacer(Modifier.height(8.dp))

            CampoTexto(
                valor = loginViewModel.passwordInput,
                alCambiar = { loginViewModel.passwordInput = it },
                etiqueta = "Contraseña",
                icono = Icons.Default.Lock,
                error = loginViewModel.errorPassword,
                teclado = KeyboardType.Password,
                transformacion = if (loginViewModel.mostrarPassword) VisualTransformation.None
                else PasswordVisualTransformation(),
                trailing = {
                    IconButton(onClick = { loginViewModel.mostrarPassword = !loginViewModel.mostrarPassword }) {
                        Icon(
                            if (loginViewModel.mostrarPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Mostrar u ocultar contraseña"
                        )
                    }
                }
            )

            AnimatedVisibility(visible = loginViewModel.errorGeneral != null, enter = fadeIn(), exit = fadeOut()) {
                loginViewModel.errorGeneral?.let { error ->
                    Column {
                        Spacer(Modifier.height(12.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                error,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))

            Button(
                onClick = { loginViewModel.autenticar()?.let(onLoginExitoso) },
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) { Text("Ingresar") }

            TextButton(onClick = onCrearCuenta, modifier = Modifier.fillMaxWidth()) {
                Text("¿No tienes cuenta? Crear cuenta")
            }

            Spacer(Modifier.height(24.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Usuarios de prueba (datos ficticios)", style = MaterialTheme.typography.labelLarge)
                    Text(
                        "Contraseña para todos: ${DatosSimulados.PASSWORD_DEMO}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(
                            onClick = { loginViewModel.usarCredencialesDemo("juan.perez@cloro-demo.cl") },
                            label = { Text("Operario") }
                        )
                        AssistChip(
                            onClick = { loginViewModel.usarCredencialesDemo("carlos.silva@cloro-demo.cl") },
                            label = { Text("Supervisor") }
                        )
                        AssistChip(
                            onClick = { loginViewModel.usarCredencialesDemo("ana.morales@cloro-demo.cl") },
                            label = { Text("Jefatura") }
                        )
                    }
                    Text(
                        "Toca un perfil para rellenar el formulario.",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
    }
}
