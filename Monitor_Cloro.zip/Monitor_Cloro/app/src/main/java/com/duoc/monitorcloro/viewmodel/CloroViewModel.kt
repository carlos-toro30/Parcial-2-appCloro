package com.duoc.monitorcloro.viewmodel

import android.app.Application
import android.net.ConnectivityManager
import android.net.Network
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.duoc.monitorcloro.data.AlmacenLocal
import com.duoc.monitorcloro.data.ApiClient
import com.duoc.monitorcloro.data.ApiSimuladaInterceptor
import com.duoc.monitorcloro.data.DatosSimulados
import com.duoc.monitorcloro.data.aDominio
import com.duoc.monitorcloro.data.aDto
import com.duoc.monitorcloro.model.AccionCorrectiva
import com.duoc.monitorcloro.model.Alerta
import com.duoc.monitorcloro.model.Correccion
import com.duoc.monitorcloro.model.EstadoAlerta
import com.duoc.monitorcloro.model.EstadoCloro
import com.duoc.monitorcloro.model.Granja
import com.duoc.monitorcloro.model.Lectura
import com.duoc.monitorcloro.model.Medicion
import com.duoc.monitorcloro.model.OrigenMedicion
import com.duoc.monitorcloro.model.PuntoMedicion
import com.duoc.monitorcloro.model.RangosCloro
import com.duoc.monitorcloro.model.Rol
import com.duoc.monitorcloro.model.TipoDesviacion
import com.duoc.monitorcloro.model.Usuario
import com.duoc.monitorcloro.utils.Formato
import com.duoc.monitorcloro.utils.NotificationHelper
import com.duoc.monitorcloro.utils.hayConexionInternet
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import java.util.UUID

/**
 * Estado compartido de toda la app (patrón MVVM + estado observable de Compose).
 * Orquesta: sesión, API, caché local, detección de desviaciones, alertas, acciones y notificaciones.
 */
class CloroViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        const val DIA_MS = 86_400_000L
        const val INTERVALO_SYNC_MS = 60_000L
    }

    private val contexto = application
    private val almacen = AlmacenLocal(application)
    private val mutexSync = Mutex()
    private var callbackRed: ConnectivityManager.NetworkCallback? = null

    // ---------------- Estado observable ----------------
    var usuario by mutableStateOf<Usuario?>(null); private set
    var granjas by mutableStateOf<List<Granja>>(emptyList()); private set
    var mediciones by mutableStateOf<List<Medicion>>(emptyList()); private set
    var correcciones by mutableStateOf<List<Correccion>>(emptyList()); private set
    var alertas by mutableStateOf<List<Alerta>>(emptyList()); private set
    var acciones by mutableStateOf<List<AccionCorrectiva>>(emptyList()); private set
    var rangos by mutableStateOf(RangosCloro()); private set
    var lecturas by mutableStateOf<Map<Int, Lectura>>(emptyMap()); private set

    var hayRedReal by mutableStateOf(true); private set
    var offlineSimulado by mutableStateOf(false); private set
    var sincronizando by mutableStateOf(false); private set
    var ultimaSync by mutableStateOf<Long?>(null); private set
    var mensaje by mutableStateOf<String?>(null); private set

    val online: Boolean get() = hayRedReal && !offlineSimulado
    val pendientesDeSincronizar: Int get() = mediciones.count { !it.sincronizada }

    init {
        ApiClient.estaOnline = { online }
        rangos = almacen.obtenerRangos()
        granjas = almacen.obtenerGranjas().ifEmpty { DatosSimulados.granjas }
        mediciones = almacen.obtenerMediciones().sortedBy { it.fechaMillis }
        correcciones = almacen.obtenerCorrecciones()
        alertas = almacen.obtenerAlertas()
        acciones = almacen.obtenerAcciones()
        ultimaSync = almacen.obtenerUltimaSync()
        usuario = almacen.obtenerSesionId()?.let { DatosSimulados.usuarioPorId(it) }
        sembrarDatosDemo()
        recalcularLecturas()
        observarRed()

        if (usuario != null) sincronizar()
        viewModelScope.launch {
            while (true) {
                delay(INTERVALO_SYNC_MS)
                if (usuario != null) ejecutarSync(manual = false)
            }
        }
    }

    override fun onCleared() {
        callbackRed?.let {
            runCatching {
                (contexto.getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as ConnectivityManager)
                    .unregisterNetworkCallback(it)
            }
        }
        super.onCleared()
    }

    fun ahora(): Long = System.currentTimeMillis()
    fun limpiarMensaje() { mensaje = null }
    fun avisar(texto: String) { mensaje = texto }

    // ---------------- Sesión y permisos ----------------
    fun iniciarSesion(u: Usuario) {
        usuario = u
        almacen.guardarSesion(u.id)
        sincronizar()
    }

    fun cerrarSesion() {
        usuario = null
        almacen.cerrarSesion()
    }

    fun puedeVerGranja(granjaId: Int): Boolean {
        val u = usuario ?: return false
        return u.rol == Rol.JEFATURA || granjaId in u.granjasAsignadas
    }

    val granjasVisibles: List<Granja> get() = granjas.filter { puedeVerGranja(it.id) }
    val puntosVisibles: List<PuntoMedicion> get() = granjasVisibles.flatMap { it.puntos }

    fun punto(id: Int): PuntoMedicion? = granjas.flatMap { it.puntos }.firstOrNull { it.id == id }
    fun granja(id: Int): Granja? = granjas.firstOrNull { it.id == id }
    private fun puntoVisible(id: Int): Boolean = punto(id)?.let { puedeVerGranja(it.granjaId) } ?: false

    val alertasVisibles: List<Alerta> get() = alertas.filter { puntoVisible(it.puntoId) }
    val alertasAbiertasVisibles: List<Alerta> get() = alertasVisibles.filter { it.estado == EstadoAlerta.ABIERTA }

    fun alerta(id: String): Alerta? = alertas.firstOrNull { it.id == id }
    fun accionesDe(alertaId: String): List<AccionCorrectiva> =
        acciones.filter { it.alertaId == alertaId }.sortedBy { it.fechaMillis }

    // ---------------- Lecturas / estadísticas ----------------
    private fun lecturaDe(m: Medicion): Lectura {
        val c = correcciones.lastOrNull { it.medicionId == m.id }
        val valor = c?.valorCorregido ?: m.valor
        return Lectura(m, valor, rangos.evaluar(valor), c != null)
    }

    fun correccionesDe(medicionId: String): List<Correccion> =
        correcciones.filter { it.medicionId == medicionId }.sortedBy { it.fechaMillis }

    private fun recalcularLecturas() {
        lecturas = mediciones.groupBy { it.puntoId }
            .mapValues { (_, lista) -> lecturaDe(lista.maxBy { it.fechaMillis }) }
    }

    fun lecturasDePunto(puntoId: Int, dias: Int): List<Lectura> {
        val desde = ahora() - dias * DIA_MS
        return mediciones.filter { it.puntoId == puntoId && it.fechaMillis >= desde }
            .sortedBy { it.fechaMillis }
            .map { lecturaDe(it) }
    }

    // ---------------- Sincronización con la API ----------------
    fun sincronizar(manual: Boolean = false) {
        viewModelScope.launch { ejecutarSync(manual) }
    }

    private suspend fun ejecutarSync(manual: Boolean) {
        if (!online) {
            if (manual) mensaje = "Sin conexión: se muestran los datos guardados en el dispositivo."
            return
        }
        if (!mutexSync.tryLock()) return
        sincronizando = true
        try {
            val api = ApiClient.api

            // 1) Subir mediciones manuales pendientes
            for (p in mediciones.filter { !it.sincronizada }) {
                api.registrar(p.aDto())
                marcarSincronizada(p.id)
            }

            // 2) Catálogo de granjas y puntos
            granjas = api.granjas().map { it.aDominio() }
            almacen.guardarGranjas(granjas)

            // 3) Primera carga: histórico de 30 días, 7 días y 24 horas
            if (mediciones.none { it.origen == OrigenMedicion.AUTOMATICA }) {
                for (dias in listOf(30, 7, 1)) fusionar(api.historico(dias).map { it.aDominio() })
            }

            // 4) Lecturas actuales -> detección automática de desviaciones
            val nuevas = fusionar(api.actuales().map { it.aDominio() })
            nuevas.forEach { procesarNuevaMedicion(it) }

            ultimaSync = ahora()
            almacen.guardarUltimaSync(ultimaSync!!)
            if (manual) mensaje = "Datos actualizados."
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (manual) mensaje = "No se pudo sincronizar. Se muestran los datos guardados."
        } finally {
            sincronizando = false
            mutexSync.unlock()
        }
    }

    private fun marcarSincronizada(id: String) {
        mediciones = mediciones.map { if (it.id == id) it.copy(sincronizada = true) else it }
        guardarMedicionesAsync()
    }

    /** Une mediciones a la caché sin duplicar. Devuelve solo las que eran nuevas. */
    private fun fusionar(nuevas: List<Medicion>): List<Medicion> {
        val ids = mediciones.asSequence().map { it.id }.toHashSet()
        val agregadas = nuevas.filter { ids.add(it.id) }
        if (agregadas.isNotEmpty()) {
            val limite = ahora() - 30 * DIA_MS
            mediciones = (mediciones + agregadas).filter { it.fechaMillis >= limite }.sortedBy { it.fechaMillis }
            recalcularLecturas()
            guardarMedicionesAsync()
        }
        return agregadas
    }

    private fun guardarMedicionesAsync() {
        val copia = mediciones
        viewModelScope.launch(Dispatchers.IO) { almacen.guardarMediciones(copia) }
    }

    private fun observarRed() {
        hayRedReal = hayConexionInternet(contexto)
        try {
            val cm = contexto.getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    viewModelScope.launch {
                        hayRedReal = true
                        if (usuario != null) ejecutarSync(manual = false)
                    }
                }

                override fun onLost(network: Network) {
                    viewModelScope.launch { hayRedReal = hayConexionInternet(contexto) }
                }
            }
            cm.registerDefaultNetworkCallback(cb)
            callbackRed = cb
        } catch (e: Exception) {
            // Sin monitoreo en vivo: se usa el estado inicial.
        }
    }

    fun cambiarOfflineSimulado(valor: Boolean) {
        offlineSimulado = valor
        if (online && usuario != null) sincronizar()
    }

    // ---------------- Desviaciones y alertas ----------------
    private fun procesarNuevaMedicion(m: Medicion) {
        val estado = rangos.evaluar(m.valor)
        val tipo = rangos.desviacion(m.valor) ?: return
        if (estado == EstadoCloro.NORMAL) return

        val abierta = alertas.firstOrNull {
            it.puntoId == m.puntoId && it.estado == EstadoAlerta.ABIERTA && it.tipo == tipo
        }
        val alertaResultante: Alerta? = when {
            abierta == null -> Alerta(
                id = "A-" + UUID.randomUUID().toString().take(8),
                puntoId = m.puntoId, medicionId = m.id, tipo = tipo,
                severidad = estado, valor = m.valor, fechaMillis = m.fechaMillis
            ).also { alertas = alertas + it }

            estado == EstadoCloro.CRITICO && abierta.severidad == EstadoCloro.ADVERTENCIA -> {
                // Escala una advertencia abierta a crítica
                val subida = abierta.copy(severidad = estado, valor = m.valor, medicionId = m.id)
                alertas = alertas.map { if (it.id == abierta.id) subida else it }
                subida
            }

            else -> null
        }

        if (alertaResultante != null) {
            almacen.guardarAlertas(alertas)
            // Destinatarios (pregunta 20): operarios y supervisores responsables del punto afectado
            val rolUsuario = usuario?.rol
            if (estado == EstadoCloro.CRITICO && rolUsuario != null && rolUsuario != Rol.JEFATURA &&
                puntoVisible(m.puntoId)
            ) {
                val codigo = punto(m.puntoId)?.codigo ?: "punto ${m.puntoId}"
                NotificationHelper.enviarNotificacionAlerta(
                    contexto,
                    "Alerta crítica de cloro",
                    "${tipo.etiqueta} en $codigo: ${Formato.ppm(m.valor)}",
                    alertaResultante.id.hashCode()
                )
            }
        }
    }

    // ---------------- Registro manual, correcciones y acciones ----------------
    fun registrarMedicion(puntoId: Int, valor: Double): Medicion? {
        val u = usuario ?: return null
        val m = Medicion(
            id = "M-" + UUID.randomUUID().toString().take(8),
            puntoId = puntoId, valor = valor, fechaMillis = ahora(),
            origen = OrigenMedicion.MANUAL, usuario = u.nombre, sincronizada = false
        )
        mediciones = (mediciones + m).sortedBy { it.fechaMillis }
        recalcularLecturas()
        guardarMedicionesAsync()
        procesarNuevaMedicion(m)
        if (online) sincronizar()
        return m
    }

    /** La medición original se conserva; la corrección queda como un evento nuevo trazable. */
    fun corregirMedicion(medicionId: String, nuevoValor: Double, motivo: String) {
        val u = usuario ?: return
        val original = mediciones.firstOrNull { it.id == medicionId } ?: return
        val c = Correccion(
            id = "C-" + UUID.randomUUID().toString().take(8),
            medicionId = medicionId,
            valorOriginal = original.valor,
            valorCorregido = nuevoValor,
            motivo = motivo.trim(),
            usuario = u.nombre,
            fechaMillis = ahora()
        )
        correcciones = correcciones + c
        almacen.guardarCorrecciones(correcciones)
        recalcularLecturas()
        mensaje = "Corrección registrada. El valor original se conserva en el historial."
    }

    fun registrarAccion(alertaId: String, descripcion: String) {
        val u = usuario ?: return
        val a = alerta(alertaId) ?: return
        val accion = AccionCorrectiva(
            id = "AC-" + UUID.randomUUID().toString().take(8),
            alertaId = alertaId,
            puntoId = a.puntoId,
            medicionId = lecturas[a.puntoId]?.medicion?.id,
            descripcion = descripcion.trim(),
            responsable = u.nombre,
            fechaMillis = ahora()
        )
        acciones = acciones + accion
        almacen.guardarAcciones(acciones)
        mensaje = "Acción correctiva registrada."
    }

    /** null = se puede cerrar; si no, devuelve el motivo que falta. */
    fun motivoNoCierre(alerta: Alerta): String? {
        val accionesAlerta = accionesDe(alerta.id)
        if (accionesAlerta.isEmpty()) return "Falta registrar una acción correctiva."
        val ultimaAccion = accionesAlerta.maxOf { it.fechaMillis }
        val lectura = lecturas[alerta.puntoId] ?: return "No hay mediciones del punto."
        if (lectura.medicion.fechaMillis < ultimaAccion) {
            return "Falta una nueva medición posterior a la acción correctiva."
        }
        if (lectura.estado != EstadoCloro.NORMAL) {
            return "La última medición (${Formato.ppm(lectura.valor)}) sigue fuera del rango normal."
        }
        return null
    }

    fun cerrarAlerta(alertaId: String) {
        val u = usuario ?: return
        val a = alerta(alertaId) ?: return
        if (u.rol != Rol.SUPERVISOR || motivoNoCierre(a) != null) return
        alertas = alertas.map {
            if (it.id == alertaId) it.copy(estado = EstadoAlerta.CERRADA, cerradaPor = u.nombre, cerradaMillis = ahora()) else it
        }
        acciones = acciones.map { if (it.alertaId == alertaId) it.copy(resuelta = true) else it }
        almacen.guardarAlertas(alertas)
        almacen.guardarAcciones(acciones)
        mensaje = "Alerta cerrada y validada."
    }

    // ---------------- Configuración y demo ----------------
    fun guardarRangos(nuevos: RangosCloro) {
        if (!nuevos.esValido()) return
        rangos = nuevos
        almacen.guardarRangos(nuevos)
        recalcularLecturas()
        mensaje = "Rangos actualizados."
    }

    /** Herramienta de demostración: la "API" entrega una lectura fuera de rango en un punto visible. */
    fun simularLecturaFueraDeRango() {
        val punto = puntosVisibles.randomOrNull() ?: return
        val valor = if ((0..1).random() == 0) 1.20 else 7.10
        ApiSimuladaInterceptor.forzarLectura(punto.id, valor)
        mensaje = "Lectura simulada de ${Formato.ppm(valor)} en ${punto.codigo}."
        sincronizar(manual = false)
    }

    fun probarNotificacion() {
        NotificationHelper.enviarNotificacionAlerta(
            contexto, "Prueba de alerta", "Así se verá una alerta crítica de cloro en este dispositivo."
        )
    }

    private fun sembrarDatosDemo() {
        if (almacen.semillaCargada()) return
        val t = ahora()
        val h = 3_600_000L
        alertas = listOf(
            Alerta("A-demo1", 3, "SEED", TipoDesviacion.BAJO, EstadoCloro.CRITICO, 1.62, t - 26 * h,
                EstadoAlerta.CERRADA, "Carlos Silva", t - 24 * h),
            Alerta("A-demo2", 7, "SEED", TipoDesviacion.ALTO, EstadoCloro.ADVERTENCIA, 5.80, t - 50 * h,
                EstadoAlerta.CERRADA, "Roberto Díaz", t - 48 * h),
            Alerta("A-demo3", 11, "SEED", TipoDesviacion.BAJO, EstadoCloro.ADVERTENCIA, 2.40, t - 5 * h)
        )
        acciones = listOf(
            AccionCorrectiva("AC-demo1", "A-demo1", 3, null,
                "Se revisó la bomba dosificadora, se repuso hipoclorito y se purgó la línea.",
                "Juan Pérez", t - 25 * h, true),
            AccionCorrectiva("AC-demo2", "A-demo2", 7, null,
                "Se redujo la dosificación del tanque y se hizo una nueva medición en el bebedero.",
                "Pedro Rojas", t - 49 * h, true)
        )
        almacen.guardarAlertas(alertas)
        almacen.guardarAcciones(acciones)
        almacen.marcarSemilla()
    }
}
