package com.duoc.monitorcloro.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.duoc.monitorcloro.data.AlmacenLocal
import com.duoc.monitorcloro.data.DatosSimulados
import com.duoc.monitorcloro.model.Rol
import com.duoc.monitorcloro.model.Usuario
import com.duoc.monitorcloro.utils.Seguridad
import com.duoc.monitorcloro.utils.Validaciones

/**
 * Formulario "Crear cuenta". Valida desde la lógica y guarda el usuario en el almacenamiento local.
 * Por seguridad, la autoinscripción solo permite roles Operario o Supervisor (Jefatura la asigna el docente/admin).
 */
class RegistroUsuarioViewModel(application: Application) : AndroidViewModel(application) {
    private val almacen = AlmacenLocal(application)

    var nombre by mutableStateOf("")
    var email by mutableStateOf("")
    var password by mutableStateOf("")
    var confirmacion by mutableStateOf("")
    var mostrarPassword by mutableStateOf(false)
    var rol by mutableStateOf(Rol.OPERARIO)
    var granjasSeleccionadas by mutableStateOf<Set<Int>>(emptySet()); private set

    var errorNombre by mutableStateOf<String?>(null); private set
    var errorEmail by mutableStateOf<String?>(null); private set
    var errorPassword by mutableStateOf<String?>(null); private set
    var errorConfirmacion by mutableStateOf<String?>(null); private set
    var errorGranjas by mutableStateOf<String?>(null); private set

    val fuerzaPassword: Float get() = Validaciones.fuerzaPassword(password)

    fun alternarGranja(id: Int) {
        granjasSeleccionadas = if (id in granjasSeleccionadas) granjasSeleccionadas - id else granjasSeleccionadas + id
        errorGranjas = null
    }

    /** Devuelve el usuario creado, o null dejando visibles los errores de cada campo. */
    fun registrar(): Usuario? {
        errorNombre = Validaciones.nombre(nombre)
        errorEmail = Validaciones.email(email)
        errorPassword = Validaciones.passwordNueva(password)
        errorConfirmacion = Validaciones.confirmacion(password, confirmacion)
        errorGranjas = if (granjasSeleccionadas.isEmpty()) "Selecciona al menos una granja" else null

        if (errorEmail == null && DatosSimulados.todosLosUsuarios.any { it.email.equals(email.trim(), ignoreCase = true) }) {
            errorEmail = "Este correo ya está registrado"
        }
        if (listOf(errorNombre, errorEmail, errorPassword, errorConfirmacion, errorGranjas).any { it != null }) return null

        val nuevo = Usuario(
            id = DatosSimulados.todosLosUsuarios.maxOf { it.id } + 1,
            nombre = nombre.trim(),
            email = email.trim().lowercase(),
            passwordHash = Seguridad.hash(password),
            rol = rol,
            granjasAsignadas = granjasSeleccionadas.sorted()
        )
        DatosSimulados.usuariosRegistrados = DatosSimulados.usuariosRegistrados + nuevo
        almacen.guardarUsuarios(DatosSimulados.usuariosRegistrados)
        return nuevo
    }
}
