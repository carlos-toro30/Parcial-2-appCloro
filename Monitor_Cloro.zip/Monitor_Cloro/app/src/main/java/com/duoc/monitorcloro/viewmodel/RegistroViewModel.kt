package com.duoc.monitorcloro.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.duoc.monitorcloro.utils.Validaciones

/** Estado y validación del formulario de medición manual de cloro libre. */
class RegistroViewModel : ViewModel() {
    var puntoIdSeleccionado by mutableStateOf<Int?>(null)
    var valorInput by mutableStateOf("")

    var errorPunto by mutableStateOf<String?>(null); private set
    var errorValor by mutableStateOf<String?>(null); private set
    var mensajeExito by mutableStateOf<String?>(null)

    /** Acepta coma o punto decimal. */
    fun valorParseado(): Double? = Validaciones.parsearPpm(valorInput)

    /** Devuelve (puntoId, valor) si el formulario es válido; si no, deja los errores visibles. */
    fun validar(): Pair<Int, Double>? {
        mensajeExito = null
        errorPunto = null
        errorValor = null

        val punto = puntoIdSeleccionado
        if (punto == null) errorPunto = "Selecciona un punto de medición"

        val valor = valorParseado()
        errorValor = Validaciones.ppm(valorInput)

        return if (punto != null && valor != null && errorValor == null) punto to valor else null
    }

    fun limpiarFormulario() {
        valorInput = ""
    }
}
