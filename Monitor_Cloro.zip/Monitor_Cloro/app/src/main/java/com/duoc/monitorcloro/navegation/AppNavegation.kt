package com.duoc.monitorcloro.navegation

import android.widget.Toast
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Opacity
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.duoc.monitorcloro.model.Rol
import com.duoc.monitorcloro.screens.PantallaAlertas
import com.duoc.monitorcloro.screens.PantallaConfigRangos
import com.duoc.monitorcloro.screens.PantallaDetalleAlerta
import com.duoc.monitorcloro.screens.PantallaDetallePunto
import com.duoc.monitorcloro.screens.PantallaLogin
import com.duoc.monitorcloro.screens.PantallaPanel
import com.duoc.monitorcloro.screens.PantallaPerfil
import com.duoc.monitorcloro.screens.PantallaPuntos
import com.duoc.monitorcloro.screens.PantallaRegistrar
import com.duoc.monitorcloro.screens.PantallaRegistroUsuario
import com.duoc.monitorcloro.viewmodel.CloroViewModel

object Rutas {
    const val LOGIN = "login"
    const val REGISTRO_USUARIO = "registro_usuario"
    const val PUNTOS = "puntos"
    const val ALERTAS = "alertas"
    const val REGISTRAR = "registrar"
    const val PANEL = "panel"
    const val PERFIL = "perfil"
    const val CONFIG = "config"
    const val DETALLE_PUNTO = "punto/{puntoId}"
    const val DETALLE_ALERTA = "alerta/{alertaId}"

    fun punto(id: Int) = "punto/$id"
    fun alerta(id: String) = "alerta/$id"
}

private data class Tab(val ruta: String, val titulo: String, val icono: ImageVector)

@Composable
fun BarraInferior(rutaActual: String, vm: CloroViewModel, onIrTab: (String) -> Unit) {
    val rol = vm.usuario?.rol ?: return
    val tabs = buildList {
        add(Tab(Rutas.PUNTOS, "Puntos", Icons.Default.Opacity))
        add(Tab(Rutas.ALERTAS, "Alertas", Icons.Default.Notifications))
        if (rol != Rol.JEFATURA) add(Tab(Rutas.REGISTRAR, "Registrar", Icons.Default.Edit))
        if (rol != Rol.OPERARIO) add(Tab(Rutas.PANEL, "Panel", Icons.Default.Dashboard))
        add(Tab(Rutas.PERFIL, "Perfil", Icons.Default.Person))
    }
    val abiertas = vm.alertasAbiertasVisibles.size

    NavigationBar {
        tabs.forEach { tab ->
            NavigationBarItem(
                selected = rutaActual == tab.ruta,
                onClick = { if (rutaActual != tab.ruta) onIrTab(tab.ruta) },
                icon = {
                    if (tab.ruta == Rutas.ALERTAS && abiertas > 0) {
                        BadgedBox(badge = { Badge { Text("$abiertas") } }) {
                            Icon(tab.icono, contentDescription = tab.titulo)
                        }
                    } else {
                        Icon(tab.icono, contentDescription = tab.titulo)
                    }
                },
                label = { Text(tab.titulo) }
            )
        }
    }
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val vm: CloroViewModel = viewModel()
    val context = LocalContext.current

    // Mensajes breves (confirmaciones, errores de sincronización) para cualquier pantalla
    LaunchedEffect(vm.mensaje) {
        vm.mensaje?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            vm.limpiarMensaje()
        }
    }

    val irTab: (String) -> Unit = { ruta ->
        navController.navigate(ruta) {
            popUpTo(Rutas.PUNTOS) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }
    val barra: @Composable (String) -> Unit = { ruta -> BarraInferior(ruta, vm, irTab) }
    val cerrarSesion: () -> Unit = {
        vm.cerrarSesion()
        navController.navigate(Rutas.LOGIN) { popUpTo(0) { inclusive = true } }
    }

    // Se calcula una sola vez: si cambiara luego, NavHost reconstruiría el grafo y reiniciaría la navegación
    val destinoInicial = remember { if (vm.usuario != null) Rutas.PUNTOS else Rutas.LOGIN }

    NavHost(
        navController = navController,
        startDestination = destinoInicial
    ) {
        composable(Rutas.LOGIN) {
            PantallaLogin(
                online = vm.online,
                onLoginExitoso = { usuario ->
                    vm.iniciarSesion(usuario)
                    navController.navigate(Rutas.PUNTOS) { popUpTo(Rutas.LOGIN) { inclusive = true } }
                },
                onCrearCuenta = { navController.navigate(Rutas.REGISTRO_USUARIO) }
            )
        }

        composable(Rutas.REGISTRO_USUARIO) {
            PantallaRegistroUsuario(
                onVolver = { navController.popBackStack() },
                onRegistrado = {
                    Toast.makeText(context, "Cuenta creada. Ya puedes iniciar sesión.", Toast.LENGTH_LONG).show()
                    navController.popBackStack()
                }
            )
        }

        composable(Rutas.PUNTOS) {
            PantallaPuntos(
                vm = vm,
                bottomBar = { barra(Rutas.PUNTOS) },
                onPunto = { navController.navigate(Rutas.punto(it)) }
            )
        }

        composable(Rutas.ALERTAS) {
            PantallaAlertas(
                vm = vm,
                bottomBar = { barra(Rutas.ALERTAS) },
                onAlerta = { navController.navigate(Rutas.alerta(it)) }
            )
        }

        composable(Rutas.REGISTRAR) {
            PantallaRegistrar(vm = vm, bottomBar = { barra(Rutas.REGISTRAR) })
        }

        composable(Rutas.PANEL) {
            PantallaPanel(
                vm = vm,
                bottomBar = { barra(Rutas.PANEL) },
                onConfig = { navController.navigate(Rutas.CONFIG) }
            )
        }

        composable(Rutas.PERFIL) {
            PantallaPerfil(
                vm = vm,
                bottomBar = { barra(Rutas.PERFIL) },
                onConfig = { navController.navigate(Rutas.CONFIG) },
                onCerrarSesion = cerrarSesion
            )
        }

        composable(Rutas.CONFIG) {
            PantallaConfigRangos(vm = vm, onVolver = { navController.popBackStack() })
        }

        composable(
            route = Rutas.DETALLE_PUNTO,
            arguments = listOf(navArgument("puntoId") { type = NavType.IntType })
        ) { entry ->
            PantallaDetallePunto(
                vm = vm,
                puntoId = entry.arguments?.getInt("puntoId") ?: -1,
                onVolver = { navController.popBackStack() },
                onAlerta = { navController.navigate(Rutas.alerta(it)) }
            )
        }

        composable(
            route = Rutas.DETALLE_ALERTA,
            arguments = listOf(navArgument("alertaId") { type = NavType.StringType })
        ) { entry ->
            PantallaDetalleAlerta(
                vm = vm,
                alertaId = entry.arguments?.getString("alertaId") ?: "",
                onVolver = { navController.popBackStack() },
                onPunto = { navController.navigate(Rutas.punto(it)) }
            )
        }
    }
}
