package com.duoc.monitorcloro.data

import android.content.Context
import com.duoc.monitorcloro.model.AccionCorrectiva
import com.duoc.monitorcloro.model.Alerta
import com.duoc.monitorcloro.model.Correccion
import com.duoc.monitorcloro.model.Granja
import com.duoc.monitorcloro.model.Medicion
import com.duoc.monitorcloro.model.RangosCloro
import com.duoc.monitorcloro.model.Usuario
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

/**
 * Persistencia local: SharedPreferences (sesión, configuración, alertas, acciones, correcciones)
 * y un archivo JSON para la caché de mediciones (volumen mayor). Permite usar la app sin conexión.
 */
class AlmacenLocal(context: Context) {
    private val prefs = context.getSharedPreferences("cloro_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val archivoMediciones = File(context.filesDir, "cache_mediciones.json")

    // --- Sesión ---
    fun guardarSesion(usuarioId: Int) = prefs.edit().putInt("sesion_usuario_id", usuarioId).apply()
    fun obtenerSesionId(): Int? = prefs.getInt("sesion_usuario_id", -1).takeIf { it != -1 }
    fun cerrarSesion() = prefs.edit().remove("sesion_usuario_id").apply()

    // --- Configuración ---
    fun guardarRangos(r: RangosCloro) = prefs.edit().putString("rangos", gson.toJson(r)).apply()
    fun obtenerRangos(): RangosCloro =
        prefs.getString("rangos", null)?.let { runCatching { gson.fromJson(it, RangosCloro::class.java) }.getOrNull() }
            ?.takeIf { it.esValido() } ?: RangosCloro()

    fun guardarUltimaSync(ms: Long) = prefs.edit().putLong("ultima_sync", ms).apply()
    fun obtenerUltimaSync(): Long? = prefs.getLong("ultima_sync", -1L).takeIf { it != -1L }

    fun semillaCargada(): Boolean = prefs.getBoolean("semilla_cargada", false)
    fun marcarSemilla() = prefs.edit().putBoolean("semilla_cargada", true).apply()

    // --- Listas pequeñas en SharedPreferences ---
    fun guardarAlertas(l: List<Alerta>) = prefs.edit().putString("alertas", gson.toJson(l)).apply()
    fun obtenerAlertas(): List<Alerta> = leer("alertas", object : TypeToken<List<Alerta>>() {})

    fun guardarAcciones(l: List<AccionCorrectiva>) = prefs.edit().putString("acciones", gson.toJson(l)).apply()
    fun obtenerAcciones(): List<AccionCorrectiva> = leer("acciones", object : TypeToken<List<AccionCorrectiva>>() {})

    fun guardarCorrecciones(l: List<Correccion>) = prefs.edit().putString("correcciones", gson.toJson(l)).apply()
    fun obtenerCorrecciones(): List<Correccion> = leer("correcciones", object : TypeToken<List<Correccion>>() {})

    fun guardarUsuarios(l: List<Usuario>) = prefs.edit().putString("usuarios_registrados", gson.toJson(l)).apply()
    fun obtenerUsuarios(): List<Usuario> = leer("usuarios_registrados", object : TypeToken<List<Usuario>>() {})

    fun guardarGranjas(l: List<Granja>) = prefs.edit().putString("granjas", gson.toJson(l)).apply()
    fun obtenerGranjas(): List<Granja> = leer("granjas", object : TypeToken<List<Granja>>() {})

    private fun <T> leer(clave: String, tipo: TypeToken<List<T>>): List<T> {
        val json = prefs.getString(clave, null) ?: return emptyList()
        return try {
            gson.fromJson<List<T>>(json, tipo.type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    // --- Caché de mediciones (archivo) ---
    fun guardarMediciones(l: List<Medicion>) {
        try {
            archivoMediciones.writeText(gson.toJson(l))
        } catch (e: Exception) {
            // Si falla la escritura la app sigue funcionando con los datos en memoria.
        }
    }

    fun obtenerMediciones(): List<Medicion> {
        if (!archivoMediciones.exists()) return emptyList()
        return try {
            gson.fromJson<List<Medicion>>(
                archivoMediciones.readText(),
                object : TypeToken<List<Medicion>>() {}.type
            ) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }
}
