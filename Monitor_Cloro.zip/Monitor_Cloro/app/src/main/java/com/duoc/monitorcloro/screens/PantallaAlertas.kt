package com.duoc.monitorcloro.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.duoc.monitorcloro.components.ChipEstado
import com.duoc.monitorcloro.components.EstadoConexionBadge
import com.duoc.monitorcloro.components.color
import com.duoc.monitorcloro.model.Alerta
import com.duoc.monitorcloro.model.EstadoAlerta
import com.duoc.monitorcloro.model.EstadoCloro
import com.duoc.monitorcloro.utils.Formato
import com.duoc.monitorcloro.viewmodel.CloroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaAlertas(
    vm: CloroViewModel,
    bottomBar: @Composable () -> Unit,
    onAlerta: (String) -> Unit
) {
    var verAbiertas by rememberSaveable { mutableStateOf(true) }
    val visibles = vm.alertasVisibles
    val lista = if (verAbiertas) {
        visibles.filter { it.estado == EstadoAlerta.ABIERTA }
            .sortedWith(compareByDescending<Alerta> { it.severidad == EstadoCloro.CRITICO }.thenBy { it.fechaMillis })
    } else {
        visibles.filter { it.estado == EstadoAlerta.CERRADA }.sortedByDescending { it.cerradaMillis ?: 0L }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Alertas") },
                actions = { EstadoConexionBadge(vm.online, vm.pendientesDeSincronizar) }
            )
        },
        bottomBar = bottomBar
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            Row(
                modifier = Modifier.padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = verAbiertas, onClick = { verAbiertas = true },
                    label = { Text("Abiertas (${visibles.count { it.estado == EstadoAlerta.ABIERTA }})") }
                )
                FilterChip(
                    selected = !verAbiertas, onClick = { verAbiertas = false },
                    label = { Text("Cerradas (${visibles.count { it.estado == EstadoAlerta.CERRADA }})") }
                )
            }
            if (lista.isEmpty()) {
                Text(
                    if (verAbiertas) "No hay alertas abiertas. Todos los puntos están dentro del rango."
                    else "Aún no hay alertas cerradas.",
                    modifier = Modifier.padding(horizontal = 16.dp),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(lista, key = { it.id }) { a ->
                    TarjetaAlerta(vm, a) { onAlerta(a.id) }
                }
            }
        }
    }
}

@Composable
fun TarjetaAlerta(vm: CloroViewModel, alerta: Alerta, onClick: () -> Unit) {
    val color = alerta.severidad.color()
    val abierta = alerta.estado == EstadoAlerta.ABIERTA
    val codigo = vm.punto(alerta.puntoId)?.codigo ?: "Punto ${alerta.puntoId}"
    val critica = abierta && alerta.severidad == EstadoCloro.CRITICO

    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        border = if (critica) BorderStroke(2.dp, color) else null,
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = if (critica) 0.2f else 0.1f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(codigo, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                ChipEstado(alerta.severidad)
            }
            Text(
                "${alerta.tipo.etiqueta} · ${Formato.ppm(alerta.valor)}",
                style = MaterialTheme.typography.bodyLarge, color = color
            )
            Text("Detectada: ${Formato.fechaHora(alerta.fechaMillis)}", style = MaterialTheme.typography.bodySmall)
            if (abierta) {
                Text(
                    "⏳ Pendiente hace ${Formato.duracion(vm.ahora() - alerta.fechaMillis)} · " +
                        "${vm.accionesDe(alerta.id).size} acción(es) registrada(s)",
                    style = MaterialTheme.typography.labelMedium
                )
            } else {
                Text(
                    "✅ Cerrada por ${alerta.cerradaPor ?: "-"} el ${alerta.cerradaMillis?.let { Formato.fechaHora(it) } ?: "-"}",
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
    }
}
