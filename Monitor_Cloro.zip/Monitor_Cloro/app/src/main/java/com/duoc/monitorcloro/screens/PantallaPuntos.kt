package com.duoc.monitorcloro.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.duoc.monitorcloro.components.EstadoConexionBadge
import com.duoc.monitorcloro.components.TarjetaKpi
import com.duoc.monitorcloro.components.TarjetaPunto
import com.duoc.monitorcloro.components.color
import com.duoc.monitorcloro.model.EstadoCloro
import com.duoc.monitorcloro.utils.Formato
import com.duoc.monitorcloro.viewmodel.CloroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaPuntos(
    vm: CloroViewModel,
    bottomBar: @Composable () -> Unit,
    onPunto: (Int) -> Unit
) {
    var granjaFiltro by rememberSaveable { mutableStateOf(0) } // 0 = todas
    val granjas = vm.granjasVisibles.filter { granjaFiltro == 0 || it.id == granjaFiltro }
    val puntosMostrados = granjas.flatMap { it.puntos }
    val estados = puntosMostrados.mapNotNull { vm.lecturas[it.id]?.estado }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Puntos de medición") },
                actions = {
                    EstadoConexionBadge(vm.online, vm.pendientesDeSincronizar)
                    IconButton(onClick = { vm.sincronizar(manual = true) }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Actualizar")
                    }
                }
            )
        },
        bottomBar = bottomBar
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            if (vm.sincronizando) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TarjetaKpi("Normal", "${estados.count { it == EstadoCloro.NORMAL }}", EstadoCloro.NORMAL.color(), Modifier.weight(1f))
                TarjetaKpi("Advertencia", "${estados.count { it == EstadoCloro.ADVERTENCIA }}", EstadoCloro.ADVERTENCIA.color(), Modifier.weight(1f))
                TarjetaKpi("Crítico", "${estados.count { it == EstadoCloro.CRITICO }}", EstadoCloro.CRITICO.color(), Modifier.weight(1f))
            }

            LazyRow(
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(selected = granjaFiltro == 0, onClick = { granjaFiltro = 0 }, label = { Text("Todas") })
                }
                items(vm.granjasVisibles, key = { it.id }) { g ->
                    FilterChip(
                        selected = granjaFiltro == g.id,
                        onClick = { granjaFiltro = g.id },
                        label = { Text(g.nombre.removePrefix("Granja ")) }
                    )
                }
            }

            Text(
                text = vm.ultimaSync?.let { "Última actualización: ${Formato.hace(it)}" }
                    ?: "Aún sin datos sincronizados",
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                granjas.forEach { g ->
                    item(key = "granja-${g.id}") {
                        Column(modifier = Modifier.padding(top = 8.dp)) {
                            Text(g.nombre, style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(g.ubicacion, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    items(g.puntos, key = { it.id }) { p ->
                        TarjetaPunto(p, vm.lecturas[p.id], vm.rangos) { onPunto(p.id) }
                    }
                }
                item { Spacer(Modifier.width(1.dp)) }
            }
        }
    }
}
