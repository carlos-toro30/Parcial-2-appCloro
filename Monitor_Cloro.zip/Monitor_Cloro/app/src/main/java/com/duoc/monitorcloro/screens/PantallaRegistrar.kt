package com.duoc.monitorcloro.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Opacity
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.duoc.monitorcloro.components.CampoTexto
import com.duoc.monitorcloro.components.ChipEstado
import com.duoc.monitorcloro.components.EstadoConexionBadge
import com.duoc.monitorcloro.model.EstadoCloro
import com.duoc.monitorcloro.model.OrigenMedicion
import com.duoc.monitorcloro.utils.Formato
import com.duoc.monitorcloro.viewmodel.CloroViewModel
import com.duoc.monitorcloro.viewmodel.RegistroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaRegistrar(
    vm: CloroViewModel,
    bottomBar: @Composable () -> Unit,
    rvm: RegistroViewModel = viewModel()
) {
    var menuAbierto by remember { mutableStateOf(false) }
    val puntos = vm.puntosVisibles
    val seleccionado = puntos.firstOrNull { it.id == rvm.puntoIdSeleccionado }
    val valorPrevio = rvm.valorParseado()
    val miNombre = vm.usuario?.nombre
    val misRegistros = vm.mediciones
        .filter { it.origen == OrigenMedicion.MANUAL && it.usuario == miNombre }
        .takeLast(5).reversed()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Registrar medición") },
                actions = { EstadoConexionBadge(vm.online, vm.pendientesDeSincronizar) }
            )
        },
        bottomBar = bottomBar
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .padding(16.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Control manual de cloro libre", style = MaterialTheme.typography.titleMedium)

            Box {
                OutlinedButton(
                    onClick = { menuAbierto = true },
                    modifier = Modifier.fillMaxWidth(),
                    border = if (rvm.errorPunto != null) BorderStroke(1.dp, MaterialTheme.colorScheme.error) else BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Icon(Icons.Default.Place, contentDescription = null)
                    Text("  " + (seleccionado?.let { "${it.codigo} · ${it.galpon}" } ?: "Seleccionar punto de medición"))
                }
                DropdownMenu(expanded = menuAbierto, onDismissRequest = { menuAbierto = false }) {
                    puntos.forEach { p ->
                        DropdownMenuItem(
                            text = { Text("${p.codigo} · ${p.galpon} · ${p.tipo.etiqueta}") },
                            onClick = {
                                rvm.puntoIdSeleccionado = p.id
                                menuAbierto = false
                            }
                        )
                    }
                }
            }
            rvm.errorPunto?.let {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = "Error", tint = MaterialTheme.colorScheme.error)
                    Text("  $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelMedium)
                }
            }

            CampoTexto(
                valor = rvm.valorInput,
                alCambiar = { rvm.valorInput = it },
                etiqueta = "Cloro libre (ppm), ej: 3,50",
                icono = Icons.Default.Opacity,
                error = rvm.errorValor,
                teclado = KeyboardType.Decimal
            )

            if (valorPrevio != null && valorPrevio in 0.0..10.0) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Con este valor el estado sería:", style = MaterialTheme.typography.bodyMedium)
                    ChipEstado(vm.rangos.evaluar(valorPrevio))
                }
            }

            Button(
                onClick = {
                    rvm.validar()?.let { (puntoId, valor) ->
                        vm.registrarMedicion(puntoId, valor)
                        val fuera = vm.rangos.evaluar(valor) != EstadoCloro.NORMAL
                        rvm.mensajeExito = buildString {
                            append(if (vm.online) "Medición guardada y enviada." else
                                "Medición guardada en el dispositivo. Se enviará al recuperar la conexión.")
                            if (fuera) append(" Se generó una alerta por valor fuera de rango.")
                        }
                        rvm.limpiarFormulario()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Guardar medición") }

            AnimatedVisibility(visible = rvm.mensajeExito != null, enter = fadeIn(), exit = fadeOut()) {
                rvm.mensajeExito?.let { mensaje ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Text(mensaje, color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(12.dp))
                    }
                }
            }

            Text("Mis últimos registros", style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(top = 8.dp))
            if (misRegistros.isEmpty()) {
                Text("Todavía no has registrado mediciones manuales.", style = MaterialTheme.typography.bodySmall)
            }
            misRegistros.forEach { m ->
                Card {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("${vm.punto(m.puntoId)?.codigo ?: m.puntoId} · ${Formato.ppm(m.valor)}",
                                style = MaterialTheme.typography.bodyMedium)
                            Text(Formato.fechaHora(m.fechaMillis), style = MaterialTheme.typography.labelSmall)
                        }
                        Text(if (m.sincronizada) "✔ Sincronizada" else "⏳ Pendiente",
                            style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}
