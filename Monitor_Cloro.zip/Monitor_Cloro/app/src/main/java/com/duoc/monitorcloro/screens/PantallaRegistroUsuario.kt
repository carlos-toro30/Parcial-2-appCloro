package com.duoc.monitorcloro.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.duoc.monitorcloro.components.CampoTexto
import com.duoc.monitorcloro.data.DatosSimulados
import com.duoc.monitorcloro.model.Rol
import com.duoc.monitorcloro.viewmodel.RegistroUsuarioViewModel

/** Formulario "Crear cuenta": nombre, correo, contraseña, confirmación, rol y granjas asignadas. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaRegistroUsuario(
    onVolver: () -> Unit,
    onRegistrado: () -> Unit,
    rvm: RegistroUsuarioViewModel = viewModel()
) {
    val fuerza by animateFloatAsState(targetValue = rvm.fuerzaPassword, label = "fuerzaPassword")

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Crear cuenta") },
                navigationIcon = {
                    IconButton(onClick = onVolver) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .padding(20.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Datos ficticios para el MVP académico", style = MaterialTheme.typography.labelMedium)

            CampoTexto(rvm.nombre, { rvm.nombre = it }, "Nombre completo", Icons.Default.Person, rvm.errorNombre)
            CampoTexto(rvm.email, { rvm.email = it }, "Correo electrónico", Icons.Default.Email, rvm.errorEmail,
                teclado = KeyboardType.Email)
            CampoTexto(
                valor = rvm.password,
                alCambiar = { rvm.password = it },
                etiqueta = "Contraseña (mín. 6 caracteres)",
                icono = Icons.Default.Lock,
                error = rvm.errorPassword,
                teclado = KeyboardType.Password,
                transformacion = if (rvm.mostrarPassword) VisualTransformation.None else PasswordVisualTransformation(),
                trailing = {
                    IconButton(onClick = { rvm.mostrarPassword = !rvm.mostrarPassword }) {
                        Icon(
                            if (rvm.mostrarPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Mostrar u ocultar contraseña"
                        )
                    }
                }
            )
            LinearProgressIndicator(progress = { fuerza }, modifier = Modifier.fillMaxWidth())
            Text(
                when {
                    rvm.password.isEmpty() -> "Seguridad de la contraseña"
                    fuerza < 0.5f -> "Seguridad: débil"
                    fuerza < 0.75f -> "Seguridad: media"
                    else -> "Seguridad: fuerte"
                },
                style = MaterialTheme.typography.labelSmall
            )
            CampoTexto(
                valor = rvm.confirmacion,
                alCambiar = { rvm.confirmacion = it },
                etiqueta = "Confirmar contraseña",
                icono = Icons.Default.Lock,
                error = rvm.errorConfirmacion,
                teclado = KeyboardType.Password,
                transformacion = if (rvm.mostrarPassword) VisualTransformation.None else PasswordVisualTransformation()
            )

            Text("Rol", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(Rol.OPERARIO, Rol.SUPERVISOR).forEach { r ->
                    FilterChip(selected = rvm.rol == r, onClick = { rvm.rol = r }, label = { Text(r.etiqueta) })
                }
            }

            Text("Granjas asignadas", style = MaterialTheme.typography.titleSmall)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DatosSimulados.granjas.forEach { g ->
                    FilterChip(
                        selected = g.id in rvm.granjasSeleccionadas,
                        onClick = { rvm.alternarGranja(g.id) },
                        label = { Text(g.nombre.removePrefix("Granja ")) }
                    )
                }
            }
            rvm.errorGranjas?.let {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = "Error", tint = MaterialTheme.colorScheme.error)
                    Text("  $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelMedium)
                }
            }

            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { if (rvm.registrar() != null) onRegistrado() },
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) { Text("Crear cuenta") }
        }
    }
}
