package com.duoc.monitorcloro.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.duoc.monitorcloro.components.ChipEstado
import com.duoc.monitorcloro.components.DialogoCorreccion
import com.duoc.monitorcloro.components.EstadoConexionBadge
import com.duoc.monitorcloro.components.GraficoLinea
import com.duoc.monitorcloro.components.TarjetaKpi
import com.duoc.monitorcloro.components.color
import com.duoc.monitorcloro.model.EstadoAlerta
import com.duoc.monitorcloro.model.Lectura
import com.duoc.monitorcloro.model.OrigenMedicion
import com.duoc.monitorcloro.model.Rol
import com.duoc.monitorcloro.model.resumenDe
import com.duoc.monitorcloro.utils.Formato
import com.duoc.monitorcloro.viewmodel.CloroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaDetallePunto(
    vm: CloroViewModel,
    puntoId: Int,
    onVolver: () -> Unit,
    onAlerta: (String) -> Unit
) {
    val punto = vm.punto(puntoId)
    var dias by rememberSaveable { mutableStateOf(1) }
    var aCorregir by remember { mutableStateOf<Lectura?>(null) }

    val serie = remember(vm.mediciones, vm.correcciones, vm.rangos, dias, puntoId) {
        vm.lecturasDePunto(puntoId, dias)
    }
    val actual = vm.lecturas[puntoId]
    val resumen = resumenDe(serie.map { it.valor })
    val alertasAbiertas = vm.alertasVisibles.filter { it.puntoId == puntoId && it.estado == EstadoAlerta.ABIERTA }
    val esSupervisor = vm.usuario?.rol == Rol.SUPERVISOR

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(punto?.codigo ?: "Punto") },
                navigationIcon = {
                    IconButton(onClick = onVolver) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                },
                actions = { EstadoConexionBadge(vm.online, vm.pendientesDeSincronizar) }
            )
        }
    ) { innerPadding ->
        if (punto == null) {
            Text("Punto no encontrado", modifier = Modifier.padding(innerPadding).padding(16.dp))
            return@Scaffold
        }
        LazyColumn(
            modifier = Modifier.padding(innerPadding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Valor actual
            item {
                val color = actual?.estado?.color() ?: MaterialTheme.colorScheme.outline
                Card(colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f))) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("${punto.galpon} · ${punto.tipo.etiqueta}", style = MaterialTheme.typography.bodyMedium)
                        Text(punto.ubicacion, style = MaterialTheme.typography.bodySmall)
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                actual?.let { Formato.ppm(it.valor) } ?: "Sin datos",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = color
                            )
                            actual?.let { ChipEstado(it.estado) }
                        }
                        actual?.let {
                            Text("Actualizado ${Formato.fechaHora(it.medicion.fechaMillis)} (${Formato.hace(it.medicion.fechaMillis)})",
                                style = MaterialTheme.typography.labelSmall)
                            vm.rangos.desviacion(it.valor)?.let { d ->
                                Text(d.etiqueta, color = color, style = MaterialTheme.typography.labelLarge)
                            }
                        }
                        Text(
                            "Normal: ${Formato.valor(vm.rangos.normalMin)}–${Formato.valor(vm.rangos.normalMax)} ppm · " +
                                "Crítico: < ${Formato.valor(vm.rangos.criticoMin)} o > ${Formato.valor(vm.rangos.criticoMax)} ppm",
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }

            if (alertasAbiertas.isNotEmpty()) {
                items(alertasAbiertas, key = { "al-${it.id}" }) { a ->
                    Card(
                        onClick = { onAlerta(a.id) },
                        colors = CardDefaults.cardColors(containerColor = a.severidad.color().copy(alpha = 0.15f))
                    ) {
                        Text(
                            "Alerta abierta: ${a.tipo.etiqueta} (${a.severidad.etiqueta}) · abierta hace ${Formato.duracion(vm.ahora() - a.fechaMillis)}. Toca para gestionarla.",
                            modifier = Modifier.padding(12.dp),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            // Período y gráfico
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = dias == 1, onClick = { dias = 1 }, label = { Text("24 horas") })
                    FilterChip(selected = dias == 7, onClick = { dias = 7 }, label = { Text("7 días") })
                    FilterChip(selected = dias == 30, onClick = { dias = 30 }, label = { Text("30 días") })
                }
            }
            item {
                Card {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Evolución del cloro libre (ppm)", style = MaterialTheme.typography.titleSmall)
                        if (serie.size >= 2) {
                            GraficoLinea(
                                puntos = serie.map { it.medicion.fechaMillis to it.valor },
                                rangos = vm.rangos,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                            Text(
                                "Verde: rango normal · Naranja: advertencia · Rojo: crítico",
                                style = MaterialTheme.typography.labelSmall
                            )
                        } else {
                            Text("Aún no hay suficientes datos para este período.",
                                style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            if (resumen != null) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TarjetaKpi("Promedio", Formato.valor(resumen.promedio), MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                        TarjetaKpi("Máximo", Formato.valor(resumen.maximo), MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                        TarjetaKpi("Mínimo", Formato.valor(resumen.minimo), MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                    }
                }
            }

            item {
                Text("Historial de mediciones", style = MaterialTheme.typography.titleMedium)
            }
            val recientes = serie.asReversed().take(40)
            items(recientes, key = { "m-${it.medicion.id}" }) { l ->
                val m = l.medicion
                Card(colors = CardDefaults.cardColors(containerColor = l.estado.color().copy(alpha = 0.08f))) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(Formato.fechaHora(m.fechaMillis), style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    if (m.origen == OrigenMedicion.MANUAL) "Manual · ${m.usuario ?: ""}" else "Automática",
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(Formato.ppm(l.valor), fontWeight = FontWeight.Bold, color = l.estado.color())
                                ChipEstado(l.estado)
                            }
                        }
                        if (!m.sincronizada) {
                            Text("⏳ Pendiente de sincronización", style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.error)
                        }
                        vm.correccionesDe(m.id).forEach { c ->
                            Text(
                                "Corregida: ${Formato.ppm(c.valorOriginal)} → ${Formato.ppm(c.valorCorregido)} · " +
                                    "${c.usuario}, ${Formato.fechaHora(c.fechaMillis)}. Motivo: ${c.motivo}",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                        if (esSupervisor) {
                            TextButton(onClick = { aCorregir = l }) { Text("Corregir medición") }
                        }
                    }
                }
            }
        }
    }

    aCorregir?.let { l ->
        DialogoCorreccion(
            valorOriginal = l.medicion.valor,
            onConfirmar = { nuevo, motivo ->
                vm.corregirMedicion(l.medicion.id, nuevo, motivo)
                aCorregir = null
            },
            onCerrar = { aCorregir = null }
        )
    }
}
