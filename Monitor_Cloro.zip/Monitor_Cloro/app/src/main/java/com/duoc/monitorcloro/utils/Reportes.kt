package com.duoc.monitorcloro.utils

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.duoc.monitorcloro.model.EstadoAlerta
import com.duoc.monitorcloro.model.OrigenMedicion
import com.duoc.monitorcloro.model.PuntoMedicion
import com.duoc.monitorcloro.model.resumenDe
import com.duoc.monitorcloro.viewmodel.CloroViewModel
import java.io.File

/**
 * Reportes de mediciones, desviaciones y acciones correctivas, filtrados por granja, punto y período
 * (pregunta 29). Se comparten como texto o como CSV (abre en Excel).
 */
object Reportes {

    /** Escapa una celda CSV (separador ';'). */
    fun celda(valor: String): String =
        "\"" + valor.replace("\r", " ").replace("\n", " ").replace("\"", "\"\"") + "\""

    private fun medicionAsociada(vm: CloroViewModel, medicionId: String?): Double? =
        medicionId?.let { id -> vm.mediciones.firstOrNull { it.id == id }?.valor }

    fun texto(vm: CloroViewModel, periodo: String, alcance: String, dias: Int, puntos: List<PuntoMedicion>): String {
        val ids = puntos.map { it.id }.toSet()
        val desde = vm.ahora() - dias * CloroViewModel.DIA_MS
        val lecturas = puntos.flatMap { vm.lecturasDePunto(it.id, dias) }
        val resumen = resumenDe(lecturas.map { it.valor })
        val alertas = vm.alertasVisibles.filter { it.puntoId in ids && it.fechaMillis >= desde }
        val acciones = vm.acciones.filter { it.puntoId in ids && it.fechaMillis >= desde }

        return buildString {
            appendLine("REPORTE DE CLORO LIBRE (datos ficticios)")
            appendLine("Período: $periodo")
            appendLine("Alcance: $alcance (${puntos.size} punto(s))")
            appendLine("Generado: ${Formato.fechaHora(vm.ahora())} por ${vm.usuario?.nombre}")
            appendLine()
            appendLine("MEDICIONES: ${lecturas.size}")
            if (resumen != null) {
                appendLine("Promedio: ${Formato.ppm(resumen.promedio)} · Máx: ${Formato.ppm(resumen.maximo)} · Mín: ${Formato.ppm(resumen.minimo)}")
            }
            appendLine()
            appendLine("DESVIACIONES: ${alertas.size}")
            alertas.sortedByDescending { it.fechaMillis }.take(15).forEach { a ->
                val codigo = vm.punto(a.puntoId)?.codigo ?: a.puntoId.toString()
                appendLine("- ${Formato.fechaHora(a.fechaMillis)} $codigo: ${a.tipo.etiqueta} ${Formato.ppm(a.valor)} " +
                    "[${a.severidad.etiqueta}] ${if (a.estado == EstadoAlerta.ABIERTA) "ABIERTA" else "cerrada"}")
            }
            appendLine()
            appendLine("ACCIONES CORRECTIVAS: ${acciones.size}")
            acciones.sortedByDescending { it.fechaMillis }.take(15).forEach { a ->
                val codigo = vm.punto(a.puntoId)?.codigo ?: a.puntoId.toString()
                val m = medicionAsociada(vm, a.medicionId)?.let { " (medición ${Formato.ppm(it)})" } ?: ""
                appendLine("- ${Formato.fechaHora(a.fechaMillis)} $codigo$m: ${a.descripcion} " +
                    "— ${a.responsable} · ${if (a.resuelta) "resuelta" else "en seguimiento"}")
            }
        }
    }

    fun csv(vm: CloroViewModel, dias: Int, puntos: List<PuntoMedicion>): String {
        val ids = puntos.map { it.id }.toSet()
        val desde = vm.ahora() - dias * CloroViewModel.DIA_MS
        fun fila(vararg c: String) = c.joinToString(";") { celda(it) }

        return buildString {
            appendLine("MEDICIONES")
            appendLine(fila("Fecha", "Granja", "Punto", "Cloro libre (ppm)", "Estado", "Origen", "Usuario", "Corregida"))
            puntos.forEach { p ->
                vm.lecturasDePunto(p.id, dias).forEach { l ->
                    appendLine(fila(
                        Formato.fechaHora(l.medicion.fechaMillis), vm.granja(p.granjaId)?.nombre ?: "", p.codigo,
                        Formato.valor(l.valor), l.estado.etiqueta,
                        if (l.medicion.origen == OrigenMedicion.MANUAL) "Manual" else "Automática",
                        l.medicion.usuario ?: "", if (l.corregida) "Sí" else "No"
                    ))
                }
            }
            appendLine()
            appendLine("DESVIACIONES")
            appendLine(fila("Fecha", "Punto", "Tipo", "Severidad", "Valor (ppm)", "Estado", "Cerrada por", "Fecha cierre"))
            vm.alertasVisibles.filter { it.puntoId in ids && it.fechaMillis >= desde }
                .sortedBy { it.fechaMillis }.forEach { a ->
                    appendLine(fila(
                        Formato.fechaHora(a.fechaMillis), vm.punto(a.puntoId)?.codigo ?: "", a.tipo.etiqueta,
                        a.severidad.etiqueta, Formato.valor(a.valor),
                        if (a.estado == EstadoAlerta.ABIERTA) "Abierta" else "Cerrada",
                        a.cerradaPor ?: "", a.cerradaMillis?.let { Formato.fechaHora(it) } ?: ""
                    ))
                }
            appendLine()
            appendLine("ACCIONES CORRECTIVAS")
            appendLine(fila("Fecha", "Hora", "Punto", "Alerta", "Descripción", "Responsable", "Medición asociada (ppm)", "Resolución"))
            vm.acciones.filter { it.puntoId in ids && it.fechaMillis >= desde }
                .sortedBy { it.fechaMillis }.forEach { a ->
                    appendLine(fila(
                        Formato.fechaHora(a.fechaMillis).substringBefore(' '), Formato.hora(a.fechaMillis),
                        vm.punto(a.puntoId)?.codigo ?: "", a.alertaId, a.descripcion, a.responsable,
                        medicionAsociada(vm, a.medicionId)?.let { Formato.valor(it) } ?: "",
                        if (a.resuelta) "Resuelta" else "En seguimiento"
                    ))
                }
        }
    }

    fun compartirTexto(context: Context, texto: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Reporte de cloro libre")
            putExtra(Intent.EXTRA_TEXT, texto)
        }
        context.startActivity(Intent.createChooser(intent, "Compartir reporte"))
    }

    fun compartirCsv(context: Context, contenido: String) {
        val dir = File(context.cacheDir, "reportes").apply { mkdirs() }
        val archivo = File(dir, "reporte_cloro_${System.currentTimeMillis()}.csv")
        archivo.writeText("﻿" + contenido, Charsets.UTF_8) // BOM para que Excel lea las tildes
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", archivo)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_SUBJECT, "Reporte de cloro libre (CSV)")
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Exportar reporte (CSV)"))
    }
}
