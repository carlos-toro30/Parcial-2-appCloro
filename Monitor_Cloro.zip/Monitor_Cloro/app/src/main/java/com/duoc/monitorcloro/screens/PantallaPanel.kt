package com.duoc.monitorcloro.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.duoc.monitorcloro.components.BarraComparacion
import com.duoc.monitorcloro.components.EstadoConexionBadge
import com.duoc.monitorcloro.components.GraficoLinea
import com.duoc.monitorcloro.components.TarjetaKpi
import com.duoc.monitorcloro.components.color
import com.duoc.monitorcloro.model.EstadoAlerta
import com.duoc.monitorcloro.model.EstadoCloro
import com.duoc.monitorcloro.model.Rol
import com.duoc.monitorcloro.model.resumenDe
import com.duoc.monitorcloro.utils.Formato
import com.duoc.monitorcloro.utils.Reportes
import com.duoc.monitorcloro.viewmodel.CloroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaPanel(
    vm: CloroViewModel,
    bottomBar: @Composable () -> Unit,
    onConfig: () -> Unit
) {
    val context = LocalContext.current
    var dias by rememberSaveable { mutableStateOf(1) }
    var granjaSel by rememberSaveable { mutableStateOf(0) } // 0 = todas
    var puntoSel by rememberSaveable { mutableStateOf(0) } // 0 = todos los puntos de la granja

    val nombrePeriodo = when (dias) { 1 -> "últimas 24 horas"; 7 -> "últimos 7 días"; else -> "últimos 30 días" }
    val puntos = vm.puntosVisibles
        .filter { granjaSel == 0 || it.granjaId == granjaSel }
        .filter { puntoSel == 0 || it.id == puntoSel }
    val idsPuntos = puntos.map { it.id }.toSet()

    val datos = remember(vm.mediciones, vm.correcciones, vm.rangos, dias, granjaSel, puntoSel, vm.granjas) {
        puntos.associateWith { vm.lecturasDePunto(it.id, dias) }
    }
    val todos = datos.values.flatten()
    val resumen = resumenDe(todos.map { it.valor })

    val estados = puntos.mapNotNull { vm.lecturas[it.id]?.estado }
    val desde = vm.ahora() - dias * CloroViewModel.DIA_MS
    val alertasPeriodo = vm.alertasVisibles.filter { it.puntoId in idsPuntos && it.fechaMillis >= desde }
    val abiertas = vm.alertasAbiertasVisibles.count { it.puntoId in idsPuntos }
    val accionesPeriodo = vm.acciones.filter { it.puntoId in idsPuntos && it.fechaMillis >= desde }

    val bucketMs = when (dias) { 1 -> 3_600_000L; 7 -> 6 * 3_600_000L; else -> 24 * 3_600_000L }
    val serieGlobal = todos.groupBy { it.medicion.fechaMillis / bucketMs }
        .toSortedMap()
        .map { (k, l) -> (k * bucketMs) to l.map { it.valor }.average() }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(if (vm.usuario?.rol == Rol.JEFATURA) "Panel de jefatura" else "Panel de supervisión") },
                actions = {
                    EstadoConexionBadge(vm.online, vm.pendientesDeSincronizar)
                    if (vm.usuario?.rol == Rol.JEFATURA) {
                        IconButton(onClick = onConfig) { Icon(Icons.Default.Settings, contentDescription = "Configurar rangos") }
                    }
                }
            )
        },
        bottomBar = bottomBar
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .padding(16.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = dias == 1, onClick = { dias = 1 }, label = { Text("24 h") })
                FilterChip(selected = dias == 7, onClick = { dias = 7 }, label = { Text("7 días") })
                FilterChip(selected = dias == 30, onClick = { dias = 30 }, label = { Text("30 días") })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = granjaSel == 0, onClick = { granjaSel = 0; puntoSel = 0 }, label = { Text("Todas") })
                vm.granjasVisibles.forEach { g ->
                    FilterChip(
                        selected = granjaSel == g.id,
                        onClick = { granjaSel = g.id; puntoSel = 0 },
                        label = { Text(g.nombre.removePrefix("Granja ")) }
                    )
                }
            }

            // Filtro por punto de la granja seleccionada
            if (granjaSel != 0) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(selected = puntoSel == 0, onClick = { puntoSel = 0 }, label = { Text("Todos los puntos") })
                    vm.granja(granjaSel)?.puntos?.forEach { p ->
                        FilterChip(selected = puntoSel == p.id, onClick = { puntoSel = p.id }, label = { Text(p.codigo) })
                    }
                }
            }

            // Estado actual
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TarjetaKpi("Normal", "${estados.count { it == EstadoCloro.NORMAL }}", EstadoCloro.NORMAL.color(), Modifier.weight(1f))
                TarjetaKpi("Advertencia", "${estados.count { it == EstadoCloro.ADVERTENCIA }}", EstadoCloro.ADVERTENCIA.color(), Modifier.weight(1f))
                TarjetaKpi("Crítico", "${estados.count { it == EstadoCloro.CRITICO }}", EstadoCloro.CRITICO.color(), Modifier.weight(1f))
                TarjetaKpi("Alertas abiertas", "$abiertas", MaterialTheme.colorScheme.primary, Modifier.weight(1f))
            }

            // Promedio / máximo / mínimo
            Text("Indicadores ($nombrePeriodo)", style = MaterialTheme.typography.titleMedium)
            if (resumen != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TarjetaKpi("Promedio ppm", Formato.valor(resumen.promedio), vm.rangos.evaluar(resumen.promedio).color(), Modifier.weight(1f))
                    TarjetaKpi("Máximo ppm", Formato.valor(resumen.maximo), vm.rangos.evaluar(resumen.maximo).color(), Modifier.weight(1f))
                    TarjetaKpi("Mínimo ppm", Formato.valor(resumen.minimo), vm.rangos.evaluar(resumen.minimo).color(), Modifier.weight(1f))
                }
            } else {
                Text("Sin datos para el período.", style = MaterialTheme.typography.bodySmall)
            }

            // Gráfico histórico
            Card {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Promedio de cloro libre en el tiempo", style = MaterialTheme.typography.titleSmall)
                    if (serieGlobal.size >= 2) {
                        GraficoLinea(serieGlobal, vm.rangos, Modifier.padding(top = 8.dp))
                    } else {
                        Text("Sin suficientes datos.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            // Comparación entre puntos
            Card {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Comparación entre puntos (promedio)", style = MaterialTheme.typography.titleSmall)
                    puntos.forEach { p ->
                        val r = resumenDe((datos[p] ?: emptyList()).map { it.valor })
                        if (r != null) {
                            BarraComparacion(
                                titulo = p.codigo,
                                detalle = "prom ${Formato.valor(r.promedio)} · máx ${Formato.valor(r.maximo)} · mín ${Formato.valor(r.minimo)}",
                                valor = r.promedio,
                                maximo = vm.rangos.criticoMax + 1.0,
                                color = vm.rangos.evaluar(r.promedio).color()
                            )
                        }
                    }
                }
            }

            // Reporte de desviaciones y acciones
            Card {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Reporte de desviaciones y acciones", style = MaterialTheme.typography.titleSmall)
                    Text("Desviaciones detectadas: ${alertasPeriodo.size}", style = MaterialTheme.typography.bodyMedium)
                    Text("  · Críticas: ${alertasPeriodo.count { it.severidad == EstadoCloro.CRITICO }}  ·  Advertencias: ${alertasPeriodo.count { it.severidad == EstadoCloro.ADVERTENCIA }}",
                        style = MaterialTheme.typography.bodySmall)
                    Text("  · Abiertas: ${alertasPeriodo.count { it.estado == EstadoAlerta.ABIERTA }}  ·  Cerradas: ${alertasPeriodo.count { it.estado == EstadoAlerta.CERRADA }}",
                        style = MaterialTheme.typography.bodySmall)
                    Text("Acciones correctivas registradas: ${accionesPeriodo.size}", style = MaterialTheme.typography.bodyMedium)
                    val alcance = listOfNotNull(
                        vm.granja(granjaSel)?.nombre ?: "Todas las granjas",
                        vm.punto(puntoSel)?.codigo
                    ).joinToString(" · ")
                    Button(
                        onClick = { Reportes.compartirTexto(context, Reportes.texto(vm, nombrePeriodo, alcance, dias, puntos)) },
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null)
                        Text("  Compartir reporte")
                    }
                    OutlinedButton(
                        onClick = { Reportes.compartirCsv(context, Reportes.csv(vm, dias, puntos)) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null)
                        Text("  Exportar CSV (Excel)")
                    }
                }
            }
        }
    }
}
