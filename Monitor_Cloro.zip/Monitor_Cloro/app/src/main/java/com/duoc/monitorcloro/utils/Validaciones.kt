package com.duoc.monitorcloro.utils

/**
 * Reglas de validación de todos los formularios, sin dependencias de Android ni de Compose.
 * Cada función devuelve el mensaje de error, o null si el valor es válido.
 */
object Validaciones {
    const val PPM_MAX = 10.0
    private val EMAIL = Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")

    /** Acepta coma o punto decimal. */
    fun parsearPpm(texto: String): Double? = texto.trim().replace(',', '.').toDoubleOrNull()

    fun ppm(texto: String): String? {
        if (texto.isBlank()) return "Ingresa el nivel de cloro libre"
        val v = parsearPpm(texto) ?: return "Ingresa un número válido (ej: 3,50)"
        if (v < 0.0 || v > PPM_MAX) return "El valor debe estar entre 0,00 y 10,00 ppm"
        return null
    }

    /** Límite de un rango configurable: número mayor que 0. */
    fun limiteRango(texto: String): String? {
        if (texto.isBlank()) return "Campo obligatorio"
        val v = parsearPpm(texto) ?: return "Ingresa un número válido (ej: 3,00)"
        if (v <= 0.0 || v > PPM_MAX) return "Debe estar entre 0,01 y 10,00 ppm"
        return null
    }

    fun descripcionAccion(texto: String): String? =
        if (texto.trim().length < 10) "Describe la acción (mínimo 10 caracteres)" else null

    fun motivoCorreccion(texto: String): String? =
        if (texto.trim().length < 5) "Describe el motivo (mín. 5 caracteres)" else null

    fun nombre(texto: String): String? = when {
        texto.isBlank() -> "El nombre no puede estar vacío"
        texto.trim().length < 3 -> "Ingresa al menos 3 caracteres"
        !texto.all { it.isLetter() || it == ' ' || it == '\'' || it == '-' } -> "Usa solo letras y espacios"
        else -> null
    }

    fun email(texto: String): String? = when {
        texto.trim().isEmpty() -> "El correo no puede estar vacío"
        !EMAIL.matches(texto.trim()) -> "Ingresa un correo válido"
        else -> null
    }

    fun passwordLogin(texto: String): String? =
        if (texto.isEmpty()) "La contraseña no puede estar vacía" else null

    fun passwordNueva(texto: String): String? = when {
        texto.isEmpty() -> "La contraseña no puede estar vacía"
        texto.length < 6 -> "Mínimo 6 caracteres"
        else -> null
    }

    fun confirmacion(password: String, confirmacion: String): String? =
        if (confirmacion != password) "Las contraseñas no coinciden" else null

    /** 0.0 (débil) a 1.0 (fuerte), para mostrar un indicador mientras se escribe. */
    fun fuerzaPassword(texto: String): Float {
        var puntos = 0
        if (texto.length >= 6) puntos++
        if (texto.length >= 10) puntos++
        if (texto.any { it.isDigit() }) puntos++
        if (texto.any { it.isUpperCase() } && texto.any { it.isLowerCase() }) puntos++
        return puntos / 4f
    }
}
