package com.duoc.monitorcloro.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.duoc.monitorcloro.components.EstadoConexionBadge
import com.duoc.monitorcloro.model.Rol
import com.duoc.monitorcloro.utils.Formato
import com.duoc.monitorcloro.viewmodel.CloroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaPerfil(
    vm: CloroViewModel,
    bottomBar: @Composable () -> Unit,
    onConfig: () -> Unit,
    onCerrarSesion: () -> Unit
) {
    val u = vm.usuario

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Perfil y conexión") },
                actions = { EstadoConexionBadge(vm.online, vm.pendientesDeSincronizar) }
            )
        },
        bottomBar = bottomBar
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .padding(16.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(u?.nombre ?: "-", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(u?.email ?: "", style = MaterialTheme.typography.bodyMedium)
                    Text("Rol: ${u?.rol?.etiqueta ?: "-"}", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "Granjas: " + vm.granjasVisibles.joinToString { it.nombre.removePrefix("Granja ") },
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            Card {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Conexión y datos locales", style = MaterialTheme.typography.titleMedium)
                    Text("Red del dispositivo: ${if (vm.hayRedReal) "conectada" else "sin conexión"}",
                        style = MaterialTheme.typography.bodyMedium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Simular modo sin conexión", style = MaterialTheme.typography.bodyMedium)
                            Text("Para demostrar consulta offline y mediciones pendientes",
                                style = MaterialTheme.typography.labelSmall)
                        }
                        Switch(checked = vm.offlineSimulado, onCheckedChange = { vm.cambiarOfflineSimulado(it) })
                    }
                    Text("Mediciones pendientes de sincronizar: ${vm.pendientesDeSincronizar}",
                        style = MaterialTheme.typography.bodyMedium)
                    Text(
                        vm.ultimaSync?.let { "Última sincronización: ${Formato.fechaHora(it)}" } ?: "Sin sincronizar aún",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Button(
                        onClick = { vm.sincronizar(manual = true) },
                        enabled = !vm.sincronizando,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (vm.sincronizando) "Sincronizando..." else "Sincronizar ahora") }
                }
            }

            Card {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Herramientas de demostración", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "La API ficticia entrega una lectura cada 5 minutos. Para no esperar, puedes forzar una lectura fuera de rango.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedButton(onClick = { vm.simularLecturaFueraDeRango() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Simular lectura fuera de rango")
                    }
                    OutlinedButton(onClick = { vm.probarNotificacion() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Probar notificación local")
                    }
                }
            }

            if (u?.rol == Rol.JEFATURA) {
                OutlinedButton(onClick = onConfig, modifier = Modifier.fillMaxWidth()) {
                    Text("Configurar rangos de cloro")
                }
            }

            OutlinedButton(onClick = onCerrarSesion, modifier = Modifier.fillMaxWidth()) {
                Text("Cerrar sesión")
            }
        }
    }
}
