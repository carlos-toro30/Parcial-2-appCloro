package com.duoc.monitorcloro.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.duoc.monitorcloro.model.RangosCloro
import com.duoc.monitorcloro.utils.Formato
import com.duoc.monitorcloro.utils.Validaciones

/** Estado y validación del formulario de rangos de cloro (cada campo con su propio error). */
class ConfigRangosViewModel : ViewModel() {
    var criticoMin by mutableStateOf("")
    var normalMin by mutableStateOf("")
    var normalMax by mutableStateOf("")
    var criticoMax by mutableStateOf("")

    var errorCriticoMin by mutableStateOf<String?>(null); private set
    var errorNormalMin by mutableStateOf<String?>(null); private set
    var errorNormalMax by mutableStateOf<String?>(null); private set
    var errorCriticoMax by mutableStateOf<String?>(null); private set

    private var iniciado = false

    fun iniciar(actuales: RangosCloro) {
        if (!iniciado) { iniciado = true; cargar(actuales) }
    }

    fun restaurar() = cargar(RangosCloro())

    private fun cargar(r: RangosCloro) {
        criticoMin = Formato.valor(r.criticoMin)
        normalMin = Formato.valor(r.normalMin)
        normalMax = Formato.valor(r.normalMax)
        criticoMax = Formato.valor(r.criticoMax)
        limpiarErrores()
    }

    fun limpiarErrores() {
        errorCriticoMin = null; errorNormalMin = null; errorNormalMax = null; errorCriticoMax = null
    }

    /** Devuelve los rangos si todo es válido; si no, deja un error visible en cada campo afectado. */
    fun validar(): RangosCloro? {
        errorCriticoMin = Validaciones.limiteRango(criticoMin)
        errorNormalMin = Validaciones.limiteRango(normalMin)
        errorNormalMax = Validaciones.limiteRango(normalMax)
        errorCriticoMax = Validaciones.limiteRango(criticoMax)

        val cMin = Validaciones.parsearPpm(criticoMin)
        val nMin = Validaciones.parsearPpm(normalMin)
        val nMax = Validaciones.parsearPpm(normalMax)
        val cMax = Validaciones.parsearPpm(criticoMax)

        if (errorNormalMin == null && errorCriticoMin == null && nMin!! <= cMin!!)
            errorNormalMin = "Debe ser mayor que el crítico mínimo"
        if (errorNormalMax == null && errorNormalMin == null && nMax!! <= nMin!!)
            errorNormalMax = "Debe ser mayor que el normal mínimo"
        if (errorCriticoMax == null && errorNormalMax == null && cMax!! <= nMax!!)
            errorCriticoMax = "Debe ser mayor que el normal máximo"

        val hayError = listOf(errorCriticoMin, errorNormalMin, errorNormalMax, errorCriticoMax).any { it != null }
        if (hayError) return null
        return RangosCloro(cMin!!, nMin!!, nMax!!, cMax!!).takeIf { it.esValido() }
    }
}
