package com.duoc.monitorcloro.model

enum class Rol(val etiqueta: String) {
    OPERARIO("Operario"),
    SUPERVISOR("Supervisor"),
    JEFATURA("Jefatura")
}

enum class EstadoCloro(val etiqueta: String) {
    NORMAL("Normal"),
    ADVERTENCIA("Advertencia"),
    CRITICO("Crítico")
}

enum class TipoDesviacion(val etiqueta: String) {
    BAJO("Cloro insuficiente"),
    ALTO("Cloro excesivo")
}

enum class TipoPunto(val etiqueta: String) {
    TANQUE("Tanque"),
    LINEA("Línea de distribución"),
    BEBEDERO("Bebedero")
}

enum class OrigenMedicion { AUTOMATICA, MANUAL }

enum class EstadoAlerta { ABIERTA, CERRADA }

data class Usuario(
    val id: Int,
    val nombre: String,
    val email: String,
    val passwordHash: String,
    val rol: Rol,
    val granjasAsignadas: List<Int>
)

data class PuntoMedicion(
    val id: Int,
    val granjaId: Int,
    val galpon: String,
    val codigo: String,
    val ubicacion: String,
    val tipo: TipoPunto
)

data class Granja(
    val id: Int,
    val nombre: String,
    val ubicacion: String,
    val puntos: List<PuntoMedicion> = emptyList()
)

/** Medición original. Nunca se modifica: las correcciones son eventos aparte ([Correccion]). */
data class Medicion(
    val id: String,
    val puntoId: Int,
    val valor: Double,
    val fechaMillis: Long,
    val origen: OrigenMedicion,
    val usuario: String?,
    val sincronizada: Boolean = true
)

data class Correccion(
    val id: String,
    val medicionId: String,
    val valorOriginal: Double,
    val valorCorregido: Double,
    val motivo: String,
    val usuario: String,
    val fechaMillis: Long
)

data class Alerta(
    val id: String,
    val puntoId: Int,
    val medicionId: String,
    val tipo: TipoDesviacion,
    val severidad: EstadoCloro,
    val valor: Double,
    val fechaMillis: Long,
    val estado: EstadoAlerta = EstadoAlerta.ABIERTA,
    val cerradaPor: String? = null,
    val cerradaMillis: Long? = null
)

data class AccionCorrectiva(
    val id: String,
    val alertaId: String,
    val puntoId: Int,
    val medicionId: String?,
    val descripcion: String,
    val responsable: String,
    val fechaMillis: Long,
    val resuelta: Boolean = false
)

/** Rangos de cloro libre (ppm). Configurables; por defecto los del documento del caso. */
data class RangosCloro(
    val criticoMin: Double = 2.0,
    val normalMin: Double = 3.0,
    val normalMax: Double = 5.0,
    val criticoMax: Double = 6.0
) {
    fun evaluar(valor: Double): EstadoCloro = when {
        valor < criticoMin || valor > criticoMax -> EstadoCloro.CRITICO
        valor < normalMin || valor > normalMax -> EstadoCloro.ADVERTENCIA
        else -> EstadoCloro.NORMAL
    }

    fun desviacion(valor: Double): TipoDesviacion? = when {
        valor < normalMin -> TipoDesviacion.BAJO
        valor > normalMax -> TipoDesviacion.ALTO
        else -> null
    }

    fun esValido(): Boolean =
        criticoMin > 0 && criticoMin < normalMin && normalMin < normalMax && normalMax < criticoMax
}

/** Medición vista con su valor efectivo (considera la última corrección, si existe). */
data class Lectura(
    val medicion: Medicion,
    val valor: Double,
    val estado: EstadoCloro,
    val corregida: Boolean
)

data class Resumen(val promedio: Double, val maximo: Double, val minimo: Double, val cantidad: Int)

fun resumenDe(valores: List<Double>): Resumen? =
    if (valores.isEmpty()) null
    else Resumen(valores.average(), valores.max(), valores.min(), valores.size)
