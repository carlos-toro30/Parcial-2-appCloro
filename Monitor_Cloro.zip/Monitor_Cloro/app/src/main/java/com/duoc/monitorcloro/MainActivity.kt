package com.duoc.monitorcloro

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.duoc.monitorcloro.data.AlmacenLocal
import com.duoc.monitorcloro.data.DatosSimulados
import com.duoc.monitorcloro.navegation.AppNavigation
import com.duoc.monitorcloro.ui.theme.MonitorCloroTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Usuarios creados desde "Crear cuenta": deben estar cargados antes de restaurar la sesión
        DatosSimulados.usuariosRegistrados = AlmacenLocal(applicationContext).obtenerUsuarios()
        setContent {
            MonitorCloroTheme {
                SolicitarPermisoNotificaciones()
                AppNavigation()
            }
        }
    }
}

/** Android 13+ exige pedir permiso en tiempo de ejecución para mostrar notificaciones. */
@Composable
private fun SolicitarPermisoNotificaciones() {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
