package com.duoc.monitorcloro.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.duoc.monitorcloro.components.CampoTexto
import com.duoc.monitorcloro.components.ChipEstado
import com.duoc.monitorcloro.components.DialogoMedicion
import com.duoc.monitorcloro.components.EstadoConexionBadge
import com.duoc.monitorcloro.components.color
import com.duoc.monitorcloro.model.EstadoAlerta
import com.duoc.monitorcloro.model.Rol
import com.duoc.monitorcloro.model.TipoDesviacion
import com.duoc.monitorcloro.ui.theme.VerdeNormal
import com.duoc.monitorcloro.utils.Formato
import com.duoc.monitorcloro.utils.Validaciones
import com.duoc.monitorcloro.viewmodel.CloroViewModel

private fun procedimiento(tipo: TipoDesviacion): List<String> = when (tipo) {
    TipoDesviacion.BAJO -> listOf(
        "Informar al supervisor responsable del punto.",
        "Verificar la medición repitiendo el control en el punto.",
        "Revisar el dosificador, el nivel de producto y posibles consumos o fugas.",
        "Corregir la dosificación y registrar la acción realizada.",
        "Realizar una nueva medición hasta quedar dentro del rango normal."
    )
    TipoDesviacion.ALTO -> listOf(
        "Informar al supervisor responsable del punto.",
        "Verificar la medición repitiendo el control en el punto.",
        "Reducir o detener la dosificación y purgar la línea afectada.",
        "Registrar la acción realizada.",
        "Realizar una nueva medición hasta quedar dentro del rango normal."
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaDetalleAlerta(
    vm: CloroViewModel,
    alertaId: String,
    onVolver: () -> Unit,
    onPunto: (Int) -> Unit
) {
    val alerta = vm.alerta(alertaId)
    var descripcion by rememberSaveable { mutableStateOf("") }
    var errorDescripcion by remember { mutableStateOf<String?>(null) }
    var mostrarDialogoMedicion by remember { mutableStateOf(false) }
    val rol = vm.usuario?.rol

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Detalle de alerta") },
                navigationIcon = {
                    IconButton(onClick = onVolver) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                },
                actions = { EstadoConexionBadge(vm.online, vm.pendientesDeSincronizar) }
            )
        }
    ) { innerPadding ->
        if (alerta == null) {
            Text("Alerta no encontrada", modifier = Modifier.padding(innerPadding).padding(16.dp))
            return@Scaffold
        }

        val punto = vm.punto(alerta.puntoId)
        val acciones = vm.accionesDe(alerta.id)
        val abierta = alerta.estado == EstadoAlerta.ABIERTA
        val color = alerta.severidad.color()
        val motivoNoCierre = if (abierta) vm.motivoNoCierre(alerta) else null
        val puedeActuar = abierta && (rol == Rol.OPERARIO || rol == Rol.SUPERVISOR)

        Column(
            modifier = Modifier
                .padding(innerPadding)
                .padding(16.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.14f))) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(punto?.codigo ?: "Punto ${alerta.puntoId}", style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold)
                        ChipEstado(alerta.severidad)
                    }
                    Text("${alerta.tipo.etiqueta} · ${Formato.ppm(alerta.valor)}", color = color,
                        style = MaterialTheme.typography.titleMedium)
                    punto?.let { Text("${vm.granja(it.granjaId)?.nombre} · ${it.galpon} · ${it.tipo.etiqueta}",
                        style = MaterialTheme.typography.bodySmall) }
                    Text("Detectada: ${Formato.fechaHora(alerta.fechaMillis)}", style = MaterialTheme.typography.bodySmall)
                    Text(
                        if (abierta) "⏳ Pendiente hace ${Formato.duracion(vm.ahora() - alerta.fechaMillis)}"
                        else "✅ Cerrada por ${alerta.cerradaPor} el ${alerta.cerradaMillis?.let { Formato.fechaHora(it) }}",
                        style = MaterialTheme.typography.labelLarge
                    )
                    vm.lecturas[alerta.puntoId]?.let {
                        Text("Última medición del punto: ${Formato.ppm(it.valor)} (${it.estado.etiqueta})",
                            style = MaterialTheme.typography.bodySmall)
                    }
                    OutlinedButton(onClick = { onPunto(alerta.puntoId) }, modifier = Modifier.padding(top = 8.dp)) {
                        Text("Ver historial del punto")
                    }
                }
            }

            if (abierta) {
                Card {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Procedimiento sugerido", style = MaterialTheme.typography.titleSmall)
                        procedimiento(alerta.tipo).forEachIndexed { i, paso ->
                            Text("${i + 1}. $paso", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            Text("Acciones correctivas (${acciones.size})", style = MaterialTheme.typography.titleMedium)
            if (acciones.isEmpty()) {
                Text("Aún no se registran acciones para esta alerta.", style = MaterialTheme.typography.bodySmall)
            }
            acciones.forEach { a ->
                Card {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(a.descripcion, style = MaterialTheme.typography.bodyMedium)
                        a.medicionId?.let { id -> vm.mediciones.firstOrNull { it.id == id } }?.let { m ->
                            Text(
                                "Medición asociada: ${Formato.ppm(m.valor)} (${Formato.fechaHora(m.fechaMillis)})",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                        Text(
                            "${a.responsable} · ${Formato.fechaHora(a.fechaMillis)} · " +
                                if (a.resuelta) "Resuelta" else "En seguimiento",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }

            if (puedeActuar) {
                CampoTexto(
                    valor = descripcion,
                    alCambiar = { descripcion = it; errorDescripcion = null },
                    etiqueta = "Describe la acción realizada",
                    icono = Icons.Default.Edit,
                    error = errorDescripcion,
                    singleLine = false,
                    minLines = 2
                )
                Button(
                    onClick = {
                        errorDescripcion = Validaciones.descripcionAccion(descripcion)
                        if (errorDescripcion == null) {
                            vm.registrarAccion(alerta.id, descripcion)
                            descripcion = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Registrar acción correctiva") }

                OutlinedButton(
                    onClick = { mostrarDialogoMedicion = true },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Registrar nueva medición de verificación") }
            }

            if (abierta && rol == Rol.SUPERVISOR) {
                Spacer(Modifier.height(4.dp))
                Button(
                    onClick = { vm.cerrarAlerta(alerta.id) },
                    enabled = motivoNoCierre == null,
                    colors = ButtonDefaults.buttonColors(containerColor = VerdeNormal),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Validar y cerrar alerta") }
                if (motivoNoCierre != null) {
                    Text("Para cerrar: $motivoNoCierre", style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.error)
                }
            }
            if (abierta && rol == Rol.JEFATURA) {
                Text("Como jefatura puedes consultar esta alerta. La gestión y el cierre los realiza el supervisor.",
                    style = MaterialTheme.typography.labelMedium)
            }
        }

        if (mostrarDialogoMedicion) {
            DialogoMedicion(
                titulo = "Nueva medición en ${punto?.codigo ?: "el punto"}",
                rangos = vm.rangos,
                onConfirmar = { valor ->
                    vm.registrarMedicion(alerta.puntoId, valor)
                    vm.avisar("Medición registrada: ${Formato.ppm(valor)}")
                    mostrarDialogoMedicion = false
                },
                onCerrar = { mostrarDialogoMedicion = false }
            )
        }
    }
}
