package com.duoc.monitorcloro.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.duoc.monitorcloro.model.EstadoCloro
import com.duoc.monitorcloro.model.Lectura
import com.duoc.monitorcloro.model.PuntoMedicion
import com.duoc.monitorcloro.model.RangosCloro
import com.duoc.monitorcloro.ui.theme.NaranjaAdvertencia
import com.duoc.monitorcloro.ui.theme.RojoCritico
import com.duoc.monitorcloro.ui.theme.VerdeNormal
import com.duoc.monitorcloro.utils.Formato

fun EstadoCloro.color(): Color = when (this) {
    EstadoCloro.NORMAL -> VerdeNormal
    EstadoCloro.ADVERTENCIA -> NaranjaAdvertencia
    EstadoCloro.CRITICO -> RojoCritico
}

@Composable
fun EstadoConexionBadge(online: Boolean, pendientes: Int = 0) {
    val fondo = if (online) VerdeNormal else RojoCritico
    val texto = (if (online) "Online" else "Offline") + if (pendientes > 0) " · $pendientes pend." else ""
    Box(
        modifier = Modifier
            .background(fondo, RoundedCornerShape(12.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = texto, color = Color.White, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun ChipEstado(estado: EstadoCloro) {
    val c = estado.color()
    Box(
        modifier = Modifier
            .background(c.copy(alpha = 0.16f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 3.dp)
    ) {
        Text(estado.etiqueta, color = c, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun TarjetaPunto(
    punto: PuntoMedicion,
    lectura: Lectura?,
    rangos: RangosCloro,
    onClick: () -> Unit
) {
    val estado = lectura?.estado
    val color = estado?.color() ?: MaterialTheme.colorScheme.outline

    val pulso = rememberInfiniteTransition(label = "pulso")
    val alphaPulso by pulso.animateFloat(
        initialValue = 0.35f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label = "alphaPulso"
    )
    val alphaBarra = if (estado == EstadoCloro.CRITICO) alphaPulso else 1f

    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(1.dp, color.copy(alpha = 0.5f)),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.07f))
    ) {
        Row(modifier = Modifier.height(IntrinsicSize.Min)) {
            Box(
                modifier = Modifier
                    .width(8.dp)
                    .fillMaxHeight()
                    .background(color.copy(alpha = alphaBarra))
            )
            Row(
                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(punto.codigo, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "${punto.galpon} · ${punto.tipo.etiqueta}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        if (lectura != null) "Actualizado ${Formato.hace(lectura.medicion.fechaMillis)}" else "Sin datos aún",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val desv = lectura?.let { rangos.desviacion(it.valor) }
                    if (desv != null && estado != EstadoCloro.NORMAL) {
                        Text(desv.etiqueta, style = MaterialTheme.typography.labelMedium, color = color)
                    }
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = lectura?.let { Formato.valor(it.valor) } ?: "--",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = color
                    )
                    Text("ppm", style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(4.dp))
                    if (estado != null) ChipEstado(estado)
                }
            }
        }
    }
}

/**
 * Gráfico de líneas dibujado con Canvas. Muestra las zonas de rango (normal / advertencia / crítico)
 * de fondo y anima el trazado de la serie.
 */
@Composable
fun GraficoLinea(
    puntos: List<Pair<Long, Double>>,
    rangos: RangosCloro,
    modifier: Modifier = Modifier
) {
    val animacion = remember(puntos.size) { Animatable(0f) }
    LaunchedEffect(puntos.size) { animacion.animateTo(1f, tween(900)) }

    val colorLinea = MaterialTheme.colorScheme.primary
    val colorEje = MaterialTheme.colorScheme.outlineVariant

    Canvas(modifier = modifier.fillMaxWidth().height(180.dp)) {
        val maxDatos = puntos.maxOfOrNull { it.second } ?: 0.0
        val yMax = maxOf(rangos.criticoMax + 1.0, maxDatos + 0.3)
        val yMin = 0.0
        fun y(v: Double): Float = (size.height * (1 - (v - yMin) / (yMax - yMin))).toFloat()

        // Zonas de fondo
        fun zona(desde: Double, hasta: Double, color: Color) {
            val yArriba = y(hasta)
            drawRect(color.copy(alpha = 0.14f), Offset(0f, yArriba), Size(size.width, y(desde) - yArriba))
        }
        zona(yMin, rangos.criticoMin, RojoCritico)
        zona(rangos.criticoMin, rangos.normalMin, NaranjaAdvertencia)
        zona(rangos.normalMin, rangos.normalMax, VerdeNormal)
        zona(rangos.normalMax, rangos.criticoMax, NaranjaAdvertencia)
        zona(rangos.criticoMax, yMax, RojoCritico)

        // Líneas de umbral
        listOf(rangos.criticoMin, rangos.normalMin, rangos.normalMax, rangos.criticoMax).forEach {
            drawLine(colorEje, Offset(0f, y(it)), Offset(size.width, y(it)), strokeWidth = 1.5f)
        }

        if (puntos.size < 2) return@Canvas
        val t0 = puntos.first().first
        val t1 = puntos.last().first
        val span = (t1 - t0).coerceAtLeast(1L).toFloat()
        fun x(t: Long): Float = size.width * (t - t0) / span

        val visibles = (puntos.size * animacion.value).toInt().coerceIn(2, puntos.size)
        val path = Path()
        puntos.take(visibles).forEachIndexed { i, (t, v) ->
            if (i == 0) path.moveTo(x(t), y(v)) else path.lineTo(x(t), y(v))
        }
        drawPath(path, colorLinea, style = Stroke(width = 4f, cap = StrokeCap.Round))

        val (tu, vu) = puntos[visibles - 1]
        drawCircle(colorLinea, radius = 8f, center = Offset(x(tu), y(vu)))
    }
}

/** Barra horizontal animada, usada para comparar puntos de medición. */
@Composable
fun BarraComparacion(
    titulo: String,
    detalle: String,
    valor: Double,
    maximo: Double,
    color: Color
) {
    var iniciar by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { iniciar = true }
    val fraccion by animateFloatAsState(
        targetValue = if (iniciar) (valor / maximo).toFloat().coerceIn(0f, 1f) else 0f,
        animationSpec = tween(900),
        label = "barra"
    )
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(titulo, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Text(detalle, style = MaterialTheme.typography.labelSmall)
        }
        LinearProgressIndicator(
            progress = { fraccion },
            modifier = Modifier.fillMaxWidth().height(10.dp),
            color = color,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}

@Composable
fun TarjetaKpi(titulo: String, valor: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f))
    ) {
        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(valor, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = color)
            Text(titulo, style = MaterialTheme.typography.labelSmall)
        }
    }
}
