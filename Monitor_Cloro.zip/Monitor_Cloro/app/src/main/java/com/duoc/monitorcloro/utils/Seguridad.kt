package com.duoc.monitorcloro.utils

import java.security.MessageDigest

/** Protección básica de credenciales: las contraseñas no se guardan ni se comparan en texto plano. */
object Seguridad {
    private const val SAL = "monitor-cloro:"

    fun hash(texto: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest((SAL + texto).toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
}
