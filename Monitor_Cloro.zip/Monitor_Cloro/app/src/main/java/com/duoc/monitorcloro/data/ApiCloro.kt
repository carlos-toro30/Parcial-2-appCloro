package com.duoc.monitorcloro.data

import com.duoc.monitorcloro.model.Granja
import com.duoc.monitorcloro.model.Medicion
import com.duoc.monitorcloro.model.OrigenMedicion
import com.duoc.monitorcloro.model.PuntoMedicion
import com.duoc.monitorcloro.model.TipoPunto
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import java.io.IOException
import java.util.concurrent.TimeUnit

// ---------- DTOs (contrato JSON de la API) ----------

data class PuntoDto(
    val id: Int,
    val granjaId: Int,
    val galpon: String,
    val codigo: String,
    val ubicacion: String,
    val tipo: String
)

data class GranjaDto(
    val id: Int,
    val nombre: String,
    val ubicacion: String,
    val puntos: List<PuntoDto>
)

data class MedicionDto(
    val id: String,
    val puntoId: Int,
    val valorPpm: Double,
    val fechaMillis: Long,
    val origen: String,
    val usuario: String?
)

// ---------- Contrato REST ----------

interface CloroApi {
    @GET("api/v1/granjas")
    suspend fun granjas(): List<GranjaDto>

    /** Última lectura de cada punto de medición. */
    @GET("api/v1/mediciones/actuales")
    suspend fun actuales(): List<MedicionDto>

    /** Serie histórica de todos los puntos: dias = 1 (cada 15 min), 7 (cada 1 h) o 30 (cada 6 h). */
    @GET("api/v1/mediciones")
    suspend fun historico(@Query("dias") dias: Int): List<MedicionDto>

    /** Registro de una medición manual (se usa al sincronizar pendientes). */
    @POST("api/v1/mediciones")
    suspend fun registrar(@Body medicion: MedicionDto): MedicionDto
}

// ---------- Mapeos DTO <-> dominio ----------

fun MedicionDto.aDominio() = Medicion(
    id = id,
    puntoId = puntoId,
    valor = valorPpm,
    fechaMillis = fechaMillis,
    origen = if (origen == "MANUAL") OrigenMedicion.MANUAL else OrigenMedicion.AUTOMATICA,
    usuario = usuario,
    sincronizada = true
)

fun Medicion.aDto() = MedicionDto(id, puntoId, valor, fechaMillis, origen.name, usuario)

fun GranjaDto.aDominio() = Granja(
    id = id,
    nombre = nombre,
    ubicacion = ubicacion,
    puntos = puntos.map {
        PuntoMedicion(
            id = it.id,
            granjaId = it.granjaId,
            galpon = it.galpon,
            codigo = it.codigo,
            ubicacion = it.ubicacion,
            tipo = runCatching { TipoPunto.valueOf(it.tipo) }.getOrDefault(TipoPunto.LINEA)
        )
    }
)

// ---------- Cliente ----------

object ApiClient {
    /**
     * true  -> la "API REST" la responde ApiSimuladaInterceptor dentro de la app (no requiere servidor).
     * false -> se consume un servidor real que cumpla el contrato de [CloroApi] en BASE_URL.
     */
    const val USAR_API_SIMULADA = true

    /** 10.0.2.2 = localhost del PC visto desde el emulador Android. */
    const val BASE_URL = "http://10.0.2.2:3000/"

    /** La app inyecta aquí su estado de conexión (red real + modo offline simulado). */
    @Volatile
    var estaOnline: () -> Boolean = { true }

    val api: CloroApi by lazy {
        val builder = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                if (!estaOnline()) throw IOException("Sin conexión")
                chain.proceed(chain.request())
            }
        if (USAR_API_SIMULADA) builder.addInterceptor(ApiSimuladaInterceptor())

        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(builder.build())
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(CloroApi::class.java)
    }
}
