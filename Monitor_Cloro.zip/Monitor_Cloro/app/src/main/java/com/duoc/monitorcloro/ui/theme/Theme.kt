package com.duoc.monitorcloro.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = Agua80,
    secondary = AguaGris80,
    tertiary = Turquesa80
)

private val LightColorScheme = lightColorScheme(
    primary = Agua40,
    secondary = AguaGris40,
    tertiary = Turquesa40
)

@Composable
fun MonitorCloroTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Se desactiva por defecto para mantener la identidad visual (agua) y colores de estado legibles
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
