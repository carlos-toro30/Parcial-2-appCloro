package com.duoc.monitorcloro.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Opacity
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.duoc.monitorcloro.components.CampoTexto
import com.duoc.monitorcloro.model.Rol
import com.duoc.monitorcloro.viewmodel.CloroViewModel
import com.duoc.monitorcloro.viewmodel.ConfigRangosViewModel

/** Rangos configurables (ficticios, definidos por el docente). Solo jefatura puede modificarlos. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaConfigRangos(
    vm: CloroViewModel,
    onVolver: () -> Unit,
    cvm: ConfigRangosViewModel = viewModel()
) {
    val editable = vm.usuario?.rol == Rol.JEFATURA
    cvm.iniciar(vm.rangos)

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text("Rangos de cloro libre") },
                navigationIcon = {
                    IconButton(onClick = onVolver) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .padding(16.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                "Normal: entre el mínimo y el máximo normal. Advertencia: entre el límite crítico y el límite normal. " +
                    "Crítico: bajo el mínimo crítico o sobre el máximo crítico.",
                style = MaterialTheme.typography.bodySmall
            )

            CampoTexto(cvm.criticoMin, { cvm.criticoMin = it; cvm.limpiarErrores() }, "Crítico por debajo de (ppm)",
                Icons.Default.Opacity, cvm.errorCriticoMin, teclado = KeyboardType.Decimal, enabled = editable)
            CampoTexto(cvm.normalMin, { cvm.normalMin = it; cvm.limpiarErrores() }, "Normal desde (ppm)",
                Icons.Default.Opacity, cvm.errorNormalMin, teclado = KeyboardType.Decimal, enabled = editable)
            CampoTexto(cvm.normalMax, { cvm.normalMax = it; cvm.limpiarErrores() }, "Normal hasta (ppm)",
                Icons.Default.Opacity, cvm.errorNormalMax, teclado = KeyboardType.Decimal, enabled = editable)
            CampoTexto(cvm.criticoMax, { cvm.criticoMax = it; cvm.limpiarErrores() }, "Crítico por encima de (ppm)",
                Icons.Default.Opacity, cvm.errorCriticoMax, teclado = KeyboardType.Decimal, enabled = editable)

            if (editable) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            cvm.validar()?.let {
                                vm.guardarRangos(it)
                                onVolver()
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Guardar") }
                    OutlinedButton(
                        onClick = { cvm.restaurar() },
                        modifier = Modifier.weight(1f)
                    ) { Text("Restaurar") }
                }
            } else {
                Text("Solo la jefatura puede modificar los rangos.", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}
