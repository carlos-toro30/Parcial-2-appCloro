package com.duoc.monitorcloro.ui.theme

import androidx.compose.ui.graphics.Color

val Agua40 = Color(0xFF0B6E99)
val AguaGris40 = Color(0xFF4F6772)
val Turquesa40 = Color(0xFF00897B)

val Agua80 = Color(0xFF8FD1F2)
val AguaGris80 = Color(0xFFB7CAD3)
val Turquesa80 = Color(0xFF7FD6CC)

// Colores semánticos de estado
val VerdeNormal = Color(0xFF2E9E5B)
val NaranjaAdvertencia = Color(0xFFE38B00)
val RojoCritico = Color(0xFFD32F2F)
