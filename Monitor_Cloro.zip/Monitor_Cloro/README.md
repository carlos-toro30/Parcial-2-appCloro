# 💧 Monitor de Cloro - Aplicación Android

**Monitor de Cloro** es una app móvil (Kotlin + Jetpack Compose) para consultar desde terreno los niveles de **cloro libre** por granja y punto de medición, identificar estados normal / advertencia / crítico, recibir alertas, revisar históricos y registrar el seguimiento de las desviaciones.

Caso DSY1105 · Desarrollo de Aplicaciones Móviles · *Medición de cloro en línea* (empresa del rubro avícola y ganadero). **Todos los datos son ficticios.**

---

## 👥 Integrantes del Equipo
* **Nombre Estudiante 1**: [Tu Nombre Completo]
* **Nombre Estudiante 2**: [Nombre de tu Compañero/a]
* **Asignatura / Sección**: Desarrollo de Aplicaciones Móviles - Duoc UC

## 📋 Planificación (Trello & GitHub)
* **Tablero de Trello:** [Enlace](https://trello.com)
* **Repositorio GitHub:** [Enlace](https://github.com)

---

## 🎯 Cobertura del caso (MVP, pregunta 35 del documento)

| Requisito MVP | Dónde está |
| :--- | :--- |
| Inicio de sesión, **crear cuenta** y perfiles | `PantallaLogin`, `PantallaRegistroUsuario`, `LoginViewModel`, `RegistroUsuarioViewModel`, roles Operario / Supervisor / Jefatura (usuarios nuevos se guardan localmente) |
| Consulta de granjas y puntos de medición | `PantallaPuntos` (3 granjas × 4 puntos, filtro por granja) |
| Niveles de cloro y estados | `TarjetaPunto`, `RangosCloro.evaluar()` |
| Consumo de datos mediante API simulada | `data/ApiCloro.kt` (Retrofit) + `data/ApiSimulada.kt` |
| Generación y consulta de alertas | `PantallaAlertas`, `PantallaDetalleAlerta` |
| Historial de mediciones (24 h / 7 d / 30 d) | `PantallaDetallePunto` |
| Registro de acciones correctivas | `PantallaDetalleAlerta` |
| Almacenamiento local básico | `data/AlmacenLocal.kt` |
| Notificaciones | `utils/NotificationHelper.kt` (locales, permiso `POST_NOTIFICATIONS`; al tocarla se abre la app) |
| Reportes (pregunta 29) | `utils/Reportes.kt` + `PantallaPanel`: filtros por granja, punto y período; compartir texto o exportar **CSV** (abre en Excel) |
| Conectividad limitada | modo offline, mediciones pendientes de sincronización, auto‑sync al volver la red |

## ✅ Cumplimiento de la pauta (Evaluación Parcial 2)

| Requisito | Evidencia en el proyecto |
| :--- | :--- |
| Interfaz organizada y navegación clara | Navigation Compose con barra inferior por rol y pantallas de detalle (`navegation/AppNavegation.kt`) |
| Formularios validados con íconos y mensajes visuales | 6 formularios: login, crear cuenta, medición manual, acción correctiva, corrección y rangos. Todos usan `components/CampoTexto` (ícono inicial, borde y mensaje en rojo con ícono de advertencia) |
| Validaciones desde la lógica | `utils/Validaciones.kt` (sin Android ni Compose) + ViewModels (`LoginViewModel`, `RegistroUsuarioViewModel`, `RegistroViewModel`, `ConfigRangosViewModel`); probadas en `ValidacionesTest` |
| Animaciones funcionales | Trazado del gráfico, barras de comparación, pulso de puntos críticos, `AnimatedVisibility` en mensajes, indicador animado de seguridad de contraseña |
| Estructura modular + MVVM + persistencia local | Paquetes `model / data / viewmodel / screens / components / utils`; SharedPreferences + archivo JSON (`AlmacenLocal`) |
| GitHub + Trello | Ver `docs/PLANIFICACION_Y_GIT.md` (tablero sugerido y convenciones de commits) |
| ≥ 2 recursos nativos | Notificaciones locales con permiso en tiempo de ejecución, estado de red en vivo (`ConnectivityManager`), compartir reporte y exportar CSV con `FileProvider` |

## 🧪 Reglas de negocio (documento de preguntas)

* **Rangos (ppm, configurables):** Normal 3–5 · Advertencia 2 a <3 ó >5 a 6 · Crítico <2 ó >6. Valores con **2 decimales** y coma (`3,50 ppm`).
* Una medición fuera de rango genera **automáticamente** una alerta, diferenciando **cloro insuficiente** (bajo) de **cloro excesivo** (alto). Una advertencia abierta que empeora a crítica se **escala**.
* Las alertas críticas disparan una **notificación local** a los **operarios y supervisores** responsables del punto (pregunta 20) y se destacan en la app (borde, barra pulsante, badge en la pestaña).
* Las alertas pendientes muestran su **antigüedad** (“Pendiente hace 2 h 10 min”).
* **Cierre de alerta:** solo el **Supervisor**, y solo si hay ≥1 acción correctiva registrada **y** una medición posterior a la acción dentro del rango normal.
* **Trazabilidad:** las mediciones originales no se modifican. Una corrección es un evento nuevo con usuario, fecha, motivo y valor corregido; el original se conserva.
* **Permisos por rol:**

| | Operario | Supervisor | Jefatura |
| :--- | :---: | :---: | :---: |
| Ver puntos y alertas | sus granjas | sus granjas | todas |
| Registrar medición manual / acción correctiva | ✅ | ✅ | — |
| Corregir mediciones, cerrar alertas | — | ✅ | — |
| Panel (promedio/máx/mín, gráficos, comparación, reporte y CSV por granja/punto/período) | — | ✅ | ✅ |
| Configurar rangos | — | — | ✅ |

---

## 🏗️ Arquitectura

```
com.duoc.monitorcloro
├── model/        Modelos de dominio (Medicion, Alerta, RangosCloro, ...)
├── data/         ApiCloro (Retrofit), ApiSimulada, AlmacenLocal, DatosSimulados
├── viewmodel/    CloroViewModel (estado global), LoginViewModel, RegistroViewModel
├── navegation/   NavHost + barra inferior por rol
├── screens/      Pantallas Compose
├── components/   Tarjetas, gráfico de líneas (Canvas), barras animadas, diálogos
├── utils/        Formato, NotificationHelper, NetworkObserver
└── ui/theme/
```

* **MVVM + estado de Compose**: la UI observa `mutableStateOf` del ViewModel; la lógica no vive en los `@Composable`.
* **Navegación**: Navigation Compose, con pestañas (Puntos, Alertas, Registrar, Panel, Perfil) y pantallas de detalle con argumentos.
* **Persistencia**: SharedPreferences (sesión, rangos, alertas, acciones, correcciones, catálogo) + archivo JSON para la caché de mediciones (30 días).
* **Animaciones**: trazado animado del gráfico, barras de comparación, pulso de puntos críticos, `AnimatedVisibility` en mensajes.
* **Recursos nativos**: notificaciones locales, estado de red en vivo (`ConnectivityManager.NetworkCallback`), compartir reporte (`Intent.ACTION_SEND`).

## 🌐 API REST (simulada)

La app usa **Retrofit + OkHttp + Gson** reales. Como el caso no exige infraestructura, el “servidor” lo implementa `ApiSimuladaInterceptor`, que responde JSON dentro de la app. Los valores se generan de forma determinista (una lectura cada 5 min por punto; algunos puntos oscilan hasta salir de rango a propósito).

| Método | Ruta | Descripción |
| :--- | :--- | :--- |
| GET | `/api/v1/granjas` | Granjas con sus puntos de medición |
| GET | `/api/v1/mediciones/actuales` | Última lectura de cada punto |
| GET | `/api/v1/mediciones?dias=1\|7\|30` | Histórico (cada 15 min / 1 h / 6 h) |
| POST | `/api/v1/mediciones` | Registro de medición manual |

Para usar un servidor propio: en `ApiClient` poner `USAR_API_SIMULADA = false` y ajustar `BASE_URL` (en el emulador, `10.0.2.2` es el `localhost` del PC). Debe respetar el contrato de `CloroApi`.

---

## 💻 Cómo ejecutar

1. Android Studio reciente (el proyecto usa AGP 9.x, Kotlin 2.2, JDK 11+) y emulador/dispositivo Android 7.0+ (API 24+; recomendado 13+ para ver notificaciones).
2. Abrir la carpeta del proyecto, esperar el *Gradle Sync* (necesita internet para descargar Retrofit/OkHttp) y ejecutar **Run**.
3. Aceptar el permiso de notificaciones al abrir la app.
4. Pruebas unitarias (rangos, validaciones, formato, hash, datos simulados, CSV): `./gradlew test`.

## 🔑 Usuarios de prueba (15 ficticios)

Contraseña para todos: **`cloro123`**. En la pantalla de login hay atajos para rellenar los 3 perfiles.

| Correo | Rol | Granjas |
| :--- | :--- | :--- |
| juan.perez@cloro-demo.cl | Operario | Melipilla |
| maria.gonzalez@cloro-demo.cl | Operario | Melipilla, San Antonio |
| carlos.silva@cloro-demo.cl | Supervisor | Melipilla |
| marcela.ortiz@cloro-demo.cl | Supervisor | San Antonio, Talca |
| ana.morales@cloro-demo.cl | Jefatura | Todas |

(El resto está en `data/DatosSimulados.kt`.) También puedes crear una cuenta nueva desde el login (rol Operario o Supervisor).

## 🎬 Guion sugerido para la demo

1. Entrar como **operario** → ver puntos y estados → abrir un punto y revisar histórico 24 h / 7 d / 30 d.
2. En **Perfil**: *Simular lectura fuera de rango* → llega la notificación y aparece la alerta crítica.
3. Abrir la alerta → **Registrar acción correctiva** → **Registrar medición de verificación** con un valor normal (ej. 4,00).
4. Cerrar sesión, entrar como **supervisor** → *Validar y cerrar alerta* (se habilita solo cuando se cumplen las condiciones). Probar *Corregir medición* en un punto.
5. Activar **Simular modo sin conexión** → registrar una medición (queda “⏳ Pendiente”) → desactivar el modo → se sincroniza sola.
6. Entrar como **jefatura** → Panel (promedio/máx/mín, comparación, reporte compartible) y ⚙️ configuración de rangos.

## ⚠️ Alcance y límites

* Datos, usuarios y umbrales ficticios; sin conexión a AMINO/ERP ni a sistemas productivos.
* Notificaciones locales (no push). Exportación a PDF/Excel, escalamiento automático, fotos y firmas quedan como evoluciones futuras.
* Las contraseñas se guardan como hash SHA-256 con sal fija (`utils/Seguridad.kt`); suficiente para el MVP académico, no para producción.
* Las notificaciones se generan mientras la app está en ejecución (la API simulada vive dentro de la app). Con un backend real, el paso siguiente sería WorkManager/FCM.
* Pendientes opcionales del documento (preguntas 6, 25 y 31): pH/temperatura/turbidez, escalamiento automático y AMINO/ERP.
